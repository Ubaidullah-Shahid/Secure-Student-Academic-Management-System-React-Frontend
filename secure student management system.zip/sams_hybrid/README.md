# SAMS — Secure Academic Management System
### v1.1.0 | Information Security Lab / Final Year Project

---

## Overview

A professional, enterprise-grade Secure Academic Management System built with React + Flask, featuring JWT authentication, RBAC, SHA-256 data integrity verification, brute-force protection, full audit logging, and a complete reports and notifications module.

---

## Tech Stack

| Layer      | Technology                                                   |
|------------|--------------------------------------------------------------|
| Frontend   | React.js, Vite, Material UI (MUI), React Router, Axios       |
| Backend    | Python Flask, Flask-JWT-Extended, Flask-Bcrypt, Flask-Limiter |
| Database   | SQLite (Flask-SQLAlchemy, Flask-Migrate)                     |
| Security   | JWT + Blacklist, bcrypt, SHA-256, RBAC, Rate Limiting        |

---

## Quick Start

```bash
# 1. Setup (first time only)
chmod +x setup.sh && ./setup.sh

# 2. Start
./start.sh

# 3. Open browser
# http://localhost:5173
```

**Default Credentials**
| Role    | Username | Password  |
|---------|----------|-----------|
| Admin   | admin    | Admin@123 |

---

## Features Added in v1.1.0 (Hybrid)

### Backend
- ✅ **JWT Token Blacklisting** — Logout properly revokes tokens server-side (prevents reuse)
- ✅ **Secure Config** — SECRET_KEY and JWT_SECRET_KEY read from env vars
- ✅ **Reports API** — 5 report types: Student, Teacher, Attendance, Grade, Security
- ✅ **Admin Notifications API** — Send to individual user or broadcast to all
- ✅ **Teacher Announcements** — Send to class or individual student

### Frontend
- ✅ **Admin Reports Page** — Tabbed reports dashboard (5 types)
- ✅ **Admin Notifications Page** — Send/manage all notifications
- ✅ **Teacher Announcements Page** — Announce to courses or individual students
- ✅ **Student Notifications Page** — View, mark-read, badge counter
- ✅ **Updated Sidebar** — All new nav items for all roles

---

## Security Features

| Feature                      | Implementation                        |
|------------------------------|---------------------------------------|
| Authentication               | JWT (access + refresh tokens)         |
| Token Revocation             | JWT Blacklist table (TokenBlocklist)  |
| Password Hashing             | bcrypt (12 rounds)                    |
| Brute Force Protection       | 5 failed attempts → 60s account lock |
| Role-Based Access Control    | Admin / Teacher / Student middleware  |
| Data Integrity               | SHA-256 hash per record               |
| Audit Logging                | All critical events logged            |
| Input Sanitization           | Server-side validation + sanitization |
| Rate Limiting                | Flask-Limiter per endpoint            |

---

## Project Structure

```
sams/
├── backend/
│   ├── app/
│   │   ├── models/
│   │   │   ├── user.py            # Users + brute force fields
│   │   │   ├── student.py         # Student + SHA-256 integrity
│   │   │   ├── teacher.py         # Teacher records
│   │   │   ├── course.py          # Courses
│   │   │   ├── enrollment.py      # Student-Course enrollment
│   │   │   ├── attendance.py      # Attendance records
│   │   │   ├── grade.py           # Grades + GPA calculation
│   │   │   ├── assignment.py      # Assignments + submissions
│   │   │   ├── notification.py    # Notifications
│   │   │   ├── audit_log.py       # Security audit trail
│   │   │   ├── department.py      # Departments
│   │   │   └── token_blocklist.py # JWT revocation (NEW v1.1)
│   │   ├── routes/
│   │   │   ├── auth.py            # Login/logout/refresh (fixed)
│   │   │   ├── admin.py           # Admin CRUD + notifications
│   │   │   ├── teacher.py         # Teacher operations
│   │   │   ├── student.py         # Student operations
│   │   │   └── reports.py         # Reports API (NEW v1.1)
│   │   ├── middleware/
│   │   │   └── auth_middleware.py # RBAC decorators
│   │   └── utils/
│   │       ├── audit.py           # Audit log helper
│   │       ├── security.py        # Password validation, sanitization
│   │       └── seed.py            # Default admin seeding
│   ├── config.py                  # App configuration (fixed)
│   └── run.py                     # Entry point
└── frontend/
    └── src/
        ├── pages/
        │   ├── admin/
        │   │   ├── Dashboard.jsx
        │   │   ├── Students.jsx
        │   │   ├── Teachers.jsx
        │   │   ├── Departments.jsx
        │   │   ├── Courses.jsx
        │   │   ├── Users.jsx
        │   │   ├── AuditLogs.jsx
        │   │   ├── SecurityCenter.jsx
        │   │   ├── Reports.jsx        (NEW v1.1)
        │   │   └── Notifications.jsx  (NEW v1.1)
        │   ├── teacher/
        │   │   ├── Dashboard.jsx
        │   │   ├── Attendance.jsx
        │   │   ├── Grades.jsx
        │   │   ├── Assignments.jsx
        │   │   └── Announcements.jsx  (NEW v1.1)
        │   └── student/
        │       ├── Dashboard.jsx
        │       ├── Profile.jsx
        │       ├── Grades.jsx
        │       ├── Attendance.jsx
        │       ├── Assignments.jsx
        │       └── Notifications.jsx  (NEW v1.1)
        ├── services/api.js            (updated v1.1)
        ├── components/Layout/
        │   ├── Sidebar.jsx            (updated v1.1)
        │   ├── Navbar.jsx
        │   └── Layout.jsx
        └── context/AuthContext.jsx
```

---

## API Endpoints

### Auth (`/api/auth`)
| Method | Endpoint           | Description           |
|--------|--------------------|-----------------------|
| POST   | /login             | Login + JWT issue     |
| POST   | /logout            | Logout + token revoke |
| POST   | /refresh           | Refresh access token  |
| GET    | /me                | Get current user      |
| POST   | /change-password   | Change own password   |

### Admin (`/api/admin`) — Admin only
| Method | Endpoint                         | Description              |
|--------|----------------------------------|--------------------------|
| GET    | /dashboard                       | Stats summary            |
| GET/POST | /students                      | List / Create students   |
| PUT/DELETE | /students/:id              | Update / Delete student  |
| GET/POST | /teachers                      | List / Create teachers   |
| GET/POST | /departments                   | Department management    |
| GET/POST | /courses                       | Course management        |
| GET/POST | /users                         | User management          |
| GET    | /audit-logs                      | Audit trail              |
| GET    | /security/locked-accounts        | Locked users             |
| GET    | /security/integrity-report       | SHA-256 status           |
| GET/POST/DELETE | /notifications          | Notification management  |

### Reports (`/api/reports`) — Admin
| Method | Endpoint              | Description              |
|--------|-----------------------|--------------------------|
| GET    | /students             | Student academic report  |
| GET    | /teachers             | Teacher workload report  |
| GET    | /attendance           | Attendance per course    |
| GET    | /grades               | Grade distribution       |
| GET    | /security             | Security event summary   |
| GET    | /class-performance/:id | Per-course report (Teacher) |

### Teacher (`/api/teacher`)
| Method | Endpoint                      | Description           |
|--------|-------------------------------|-----------------------|
| GET    | /dashboard                    | Teacher overview      |
| GET    | /courses                      | Assigned courses      |
| GET    | /courses/:id/students         | Students in course    |
| GET/POST | /attendance               | Attendance CRUD       |
| GET/POST | /grades                   | Marks management      |
| GET/POST/PUT/DELETE | /assignments | Assignment CRUD   |

### Student (`/api/student`)
| Method | Endpoint                    | Description             |
|--------|-----------------------------|-------------------------|
| GET    | /dashboard                  | Student overview        |
| GET/PUT | /profile                   | Profile view/edit       |
| GET    | /courses                    | Enrolled courses        |
| GET    | /attendance                 | Attendance records      |
| GET    | /grades                     | Grade records + GPA     |
| GET    | /assignments                | Assignments + deadlines |
| POST   | /assignments/:id/submit     | Submit assignment       |
| GET    | /notifications              | View notifications      |
| PUT    | /notifications/:id/read     | Mark notification read  |

---

*SAMS — Information Security Lab Project 2024*
