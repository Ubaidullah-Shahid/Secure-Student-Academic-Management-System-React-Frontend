from functools import wraps
from flask import jsonify
from flask_jwt_extended import verify_jwt_in_request, get_jwt_identity
from app.models.user import User


def roles_required(*roles):
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            verify_jwt_in_request()
            user_id = int(get_jwt_identity())
            user = User.query.get(user_id)
            if not user or not user.is_active:
                return jsonify({'error': 'Account is deactivated or not found'}), 403
            if user.role not in roles:
                return jsonify({'error': f'Access denied. Required roles: {", ".join(roles)}'}), 403
            return fn(*args, **kwargs)
        return wrapper
    return decorator


def admin_required(fn):
    return roles_required('admin')(fn)


def teacher_required(fn):
    return roles_required('admin', 'teacher')(fn)


def student_required(fn):
    return roles_required('admin', 'teacher', 'student')(fn)
