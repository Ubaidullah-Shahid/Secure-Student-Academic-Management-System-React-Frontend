from app.models.user import User
from app.models.department import Department
from app.models.course import Course
from app.models.student import Student
from app.models.teacher import Teacher
from app.models.enrollment import Enrollment
from app.models.attendance import Attendance
from app.models.grade import Grade
from app.models.assignment import Assignment, AssignmentSubmission
from app.models.audit_log import AuditLog
from app.models.notification import Notification
from app.models.token_blocklist import TokenBlocklist
