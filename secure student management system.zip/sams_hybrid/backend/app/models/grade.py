from app import db
from datetime import datetime, timezone


class Grade(db.Model):
    __tablename__ = 'grades'

    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('students.id'), nullable=False)
    course_id = db.Column(db.Integer, db.ForeignKey('courses.id'), nullable=False)
    midterm_marks = db.Column(db.Float, default=0.0)
    final_marks = db.Column(db.Float, default=0.0)
    assignment_marks = db.Column(db.Float, default=0.0)
    quiz_marks = db.Column(db.Float, default=0.0)
    total_marks = db.Column(db.Float, default=0.0)
    grade_letter = db.Column(db.String(5), nullable=True)
    grade_points = db.Column(db.Float, default=0.0)
    semester = db.Column(db.String(20), nullable=True)
    remarks = db.Column(db.String(200), nullable=True)
    updated_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))

    __table_args__ = (db.UniqueConstraint('student_id', 'course_id', 'semester'),)

    def calculate_grade(self):
        total = (self.midterm_marks or 0) + (self.final_marks or 0) + (self.assignment_marks or 0) + (self.quiz_marks or 0)
        self.total_marks = round(total, 2)
        if total >= 90: self.grade_letter, self.grade_points = 'A+', 4.0
        elif total >= 85: self.grade_letter, self.grade_points = 'A', 4.0
        elif total >= 80: self.grade_letter, self.grade_points = 'A-', 3.7
        elif total >= 75: self.grade_letter, self.grade_points = 'B+', 3.3
        elif total >= 70: self.grade_letter, self.grade_points = 'B', 3.0
        elif total >= 65: self.grade_letter, self.grade_points = 'B-', 2.7
        elif total >= 60: self.grade_letter, self.grade_points = 'C+', 2.3
        elif total >= 55: self.grade_letter, self.grade_points = 'C', 2.0
        elif total >= 50: self.grade_letter, self.grade_points = 'C-', 1.7
        elif total >= 45: self.grade_letter, self.grade_points = 'D', 1.0
        else: self.grade_letter, self.grade_points = 'F', 0.0

    def to_dict(self):
        return {
            'id': self.id,
            'student_id': self.student_id,
            'student_name': f"{self.student.first_name} {self.student.last_name}" if self.student else None,
            'course_id': self.course_id,
            'course_name': self.course.name if self.course else None,
            'course_code': self.course.code if self.course else None,
            'midterm_marks': self.midterm_marks,
            'final_marks': self.final_marks,
            'assignment_marks': self.assignment_marks,
            'quiz_marks': self.quiz_marks,
            'total_marks': self.total_marks,
            'grade_letter': self.grade_letter,
            'grade_points': self.grade_points,
            'semester': self.semester,
            'remarks': self.remarks,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }
