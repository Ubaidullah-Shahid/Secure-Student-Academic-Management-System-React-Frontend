from app import db
from datetime import datetime, timezone
import hashlib


class Teacher(db.Model):
    __tablename__ = 'teachers'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, unique=True)
    teacher_id = db.Column(db.String(20), unique=True, nullable=False)
    first_name = db.Column(db.String(80), nullable=False)
    last_name = db.Column(db.String(80), nullable=False)
    email = db.Column(db.String(120), nullable=False)
    phone = db.Column(db.String(20), nullable=True)
    department_id = db.Column(db.Integer, db.ForeignKey('departments.id'), nullable=True)
    specialization = db.Column(db.String(150), nullable=True)
    qualification = db.Column(db.String(100), nullable=True)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    integrity_hash = db.Column(db.String(64), nullable=True)

    courses = db.relationship('Course', backref='teacher', lazy=True)

    def _compute_hash(self):
        data = f"{self.teacher_id}{self.first_name}{self.last_name}{self.email}{self.department_id}"
        return hashlib.sha256(data.encode()).hexdigest()

    def update_integrity_hash(self):
        self.integrity_hash = self._compute_hash()

    def verify_integrity(self):
        if not self.integrity_hash:
            return 'UNVERIFIED'
        computed = self._compute_hash()
        return 'VALID' if computed == self.integrity_hash else 'TAMPERED'

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'teacher_id': self.teacher_id,
            'first_name': self.first_name,
            'last_name': self.last_name,
            'full_name': f"{self.first_name} {self.last_name}",
            'email': self.email,
            'phone': self.phone,
            'department_id': self.department_id,
            'department_name': self.department.name if self.department else None,
            'specialization': self.specialization,
            'qualification': self.qualification,
            'is_active': self.is_active,
            'course_count': len(self.courses),
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'integrity_status': self.verify_integrity()
        }
