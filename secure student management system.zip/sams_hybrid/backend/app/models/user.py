from app import db, bcrypt
from datetime import datetime, timezone
import hashlib
import json


class User(db.Model):
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    role = db.Column(db.String(20), nullable=False, default='student')
    is_active = db.Column(db.Boolean, default=True)
    failed_attempts = db.Column(db.Integer, default=0)
    lock_until = db.Column(db.DateTime, nullable=True)
    last_login = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    integrity_hash = db.Column(db.String(64), nullable=True)

    student = db.relationship('Student', backref='user', uselist=False, cascade='all, delete-orphan')
    teacher = db.relationship('Teacher', backref='user', uselist=False, cascade='all, delete-orphan')
    audit_logs = db.relationship('AuditLog', backref='user', lazy=True, foreign_keys='AuditLog.user_id')

    def set_password(self, password):
        self.password_hash = bcrypt.generate_password_hash(password).decode('utf-8')
        self._update_integrity_hash()

    def check_password(self, password):
        return bcrypt.check_password_hash(self.password_hash, password)

    def _compute_hash(self):
        data = f"{self.id}{self.username}{self.email}{self.role}{self.password_hash}"
        return hashlib.sha256(data.encode()).hexdigest()

    def _update_integrity_hash(self):
        if self.id:
            self.integrity_hash = self._compute_hash()

    def verify_integrity(self):
        if not self.integrity_hash:
            return 'UNVERIFIED'
        computed = self._compute_hash()
        if computed == self.integrity_hash:
            return 'VALID'
        return 'TAMPERED'

    def is_locked(self):
        if self.lock_until and datetime.now(timezone.utc) < self.lock_until.replace(tzinfo=timezone.utc):
            return True
        return False

    def to_dict(self):
        return {
            'id': self.id,
            'username': self.username,
            'email': self.email,
            'role': self.role,
            'is_active': self.is_active,
            'failed_attempts': self.failed_attempts,
            'last_login': self.last_login.isoformat() if self.last_login else None,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'integrity_status': self.verify_integrity()
        }
