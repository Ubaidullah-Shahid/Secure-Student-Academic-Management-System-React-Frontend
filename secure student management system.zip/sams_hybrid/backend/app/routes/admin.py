from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from app import db
from app.models.user import User
from app.models.student import Student
from app.models.teacher import Teacher
from app.models.department import Department
from app.models.course import Course
from app.models.enrollment import Enrollment
from app.models.audit_log import AuditLog
from app.models.notification import Notification
from app.middleware.auth_middleware import admin_required
from app.utils.audit import log_action
from app.utils.security import validate_password, sanitize_string, get_ip_address
from datetime import datetime, timezone

admin_bp = Blueprint('admin', __name__)


def get_current_user():
    from flask_jwt_extended import get_jwt_identity
    return User.query.get(int(get_jwt_identity()))


# ── Dashboard ──────────────────────────────────────────────────────────────
@admin_bp.route('/dashboard', methods=['GET'])
@admin_required
def dashboard():
    total_students = Student.query.count()
    total_teachers = Teacher.query.count()
    total_courses = Course.query.count()
    total_departments = Department.query.count()
    total_users = User.query.count()
    locked_accounts = User.query.filter(User.lock_until != None).count()
    recent_logs = AuditLog.query.order_by(AuditLog.timestamp.desc()).limit(10).all()
    return jsonify({
        'stats': {
            'total_students': total_students,
            'total_teachers': total_teachers,
            'total_courses': total_courses,
            'total_departments': total_departments,
            'total_users': total_users,
            'locked_accounts': locked_accounts
        },
        'recent_logs': [l.to_dict() for l in recent_logs]
    }), 200


# ── Users ──────────────────────────────────────────────────────────────────
@admin_bp.route('/users', methods=['GET'])
@admin_required
def get_users():
    users = User.query.all()
    return jsonify({'users': [u.to_dict() for u in users]}), 200


@admin_bp.route('/users/<int:uid>', methods=['GET'])
@admin_required
def get_user(uid):
    user = User.query.get_or_404(uid)
    return jsonify({'user': user.to_dict()}), 200


@admin_bp.route('/users/<int:uid>', methods=['PUT'])
@admin_required
def update_user(uid):
    user = User.query.get_or_404(uid)
    data = request.get_json()
    ip = get_ip_address(request)
    me = get_current_user()
    if 'is_active' in data:
        user.is_active = data['is_active']
    if 'email' in data:
        user.email = sanitize_string(data['email'], 120)
    db.session.commit()
    log_action('USER_UPDATED', username=me.username, user_id=me.id, resource='User', resource_id=uid, ip_address=ip)
    return jsonify({'message': 'User updated', 'user': user.to_dict()}), 200


@admin_bp.route('/users/<int:uid>/reset-password', methods=['POST'])
@admin_required
def reset_password(uid):
    user = User.query.get_or_404(uid)
    data = request.get_json()
    me = get_current_user()
    ip = get_ip_address(request)
    new_password = data.get('new_password', '')
    errors = validate_password(new_password)
    if errors:
        return jsonify({'error': 'Weak password', 'details': errors}), 400
    user.set_password(new_password)
    user._update_integrity_hash()
    db.session.commit()
    log_action('PASSWORD_RESET', username=me.username, user_id=me.id, resource='User', resource_id=uid, ip_address=ip)
    return jsonify({'message': 'Password reset successfully'}), 200


@admin_bp.route('/users/<int:uid>/unlock', methods=['POST'])
@admin_required
def unlock_user(uid):
    user = User.query.get_or_404(uid)
    me = get_current_user()
    ip = get_ip_address(request)
    user.failed_attempts = 0
    user.lock_until = None
    db.session.commit()
    log_action('ACCOUNT_UNLOCKED', username=me.username, user_id=me.id, resource='User', resource_id=uid, ip_address=ip)
    return jsonify({'message': 'Account unlocked'}), 200


@admin_bp.route('/users/<int:uid>', methods=['DELETE'])
@admin_required
def delete_user(uid):
    user = User.query.get_or_404(uid)
    me = get_current_user()
    ip = get_ip_address(request)
    if user.id == me.id:
        return jsonify({'error': 'Cannot delete your own account'}), 400
    db.session.delete(user)
    db.session.commit()
    log_action('USER_DELETED', username=me.username, user_id=me.id, resource='User', resource_id=uid, ip_address=ip)
    return jsonify({'message': 'User deleted'}), 200


# ── Students ───────────────────────────────────────────────────────────────
@admin_bp.route('/students', methods=['GET'])
@admin_required
def get_students():
    students = Student.query.all()
    return jsonify({'students': [s.to_dict() for s in students]}), 200


@admin_bp.route('/students', methods=['POST'])
@admin_required
def create_student():
    data = request.get_json()
    me = get_current_user()
    ip = get_ip_address(request)

    required = ['username', 'email', 'password', 'first_name', 'last_name', 'student_id']
    for field in required:
        if not data.get(field):
            return jsonify({'error': f'{field} is required'}), 400

    errors = validate_password(data['password'])
    if errors:
        return jsonify({'error': 'Weak password', 'details': errors}), 400

    if User.query.filter_by(username=data['username']).first():
        return jsonify({'error': 'Username already exists'}), 409
    if Student.query.filter_by(student_id=data['student_id']).first():
        return jsonify({'error': 'Student ID already exists'}), 409

    user = User(username=sanitize_string(data['username']), email=sanitize_string(data['email']), role='student', is_active=True)
    user.set_password(data['password'])
    db.session.add(user)
    db.session.flush()
    user._update_integrity_hash()

    student = Student(
        user_id=user.id,
        student_id=sanitize_string(data['student_id']),
        first_name=sanitize_string(data['first_name']),
        last_name=sanitize_string(data['last_name']),
        email=sanitize_string(data['email']),
        phone=sanitize_string(data.get('phone', '')),
        gender=data.get('gender'),
        address=sanitize_string(data.get('address', ''), 500),
        department_id=data.get('department_id'),
        semester=data.get('semester', 1)
    )
    student.update_integrity_hash()
    db.session.add(student)
    db.session.commit()

    log_action('STUDENT_CREATED', username=me.username, user_id=me.id, resource='Student', resource_id=student.id, ip_address=ip)
    return jsonify({'message': 'Student created', 'student': student.to_dict()}), 201


@admin_bp.route('/students/<int:sid>', methods=['GET'])
@admin_required
def get_student(sid):
    student = Student.query.get_or_404(sid)
    return jsonify({'student': student.to_dict()}), 200


@admin_bp.route('/students/<int:sid>', methods=['PUT'])
@admin_required
def update_student(sid):
    student = Student.query.get_or_404(sid)
    data = request.get_json()
    me = get_current_user()
    ip = get_ip_address(request)

    fields = ['first_name', 'last_name', 'phone', 'gender', 'address', 'semester', 'department_id', 'is_active']
    for f in fields:
        if f in data:
            setattr(student, f, data[f])

    student.update_integrity_hash()
    db.session.commit()
    log_action('STUDENT_UPDATED', username=me.username, user_id=me.id, resource='Student', resource_id=sid, ip_address=ip)
    return jsonify({'message': 'Student updated', 'student': student.to_dict()}), 200


@admin_bp.route('/students/<int:sid>', methods=['DELETE'])
@admin_required
def delete_student(sid):
    student = Student.query.get_or_404(sid)
    me = get_current_user()
    ip = get_ip_address(request)
    user = User.query.get(student.user_id)
    db.session.delete(student)
    if user:
        db.session.delete(user)
    db.session.commit()
    log_action('STUDENT_DELETED', username=me.username, user_id=me.id, resource='Student', resource_id=sid, ip_address=ip)
    return jsonify({'message': 'Student deleted'}), 200


# ── Teachers ───────────────────────────────────────────────────────────────
@admin_bp.route('/teachers', methods=['GET'])
@admin_required
def get_teachers():
    teachers = Teacher.query.all()
    return jsonify({'teachers': [t.to_dict() for t in teachers]}), 200


@admin_bp.route('/teachers', methods=['POST'])
@admin_required
def create_teacher():
    data = request.get_json()
    me = get_current_user()
    ip = get_ip_address(request)

    required = ['username', 'email', 'password', 'first_name', 'last_name', 'teacher_id']
    for field in required:
        if not data.get(field):
            return jsonify({'error': f'{field} is required'}), 400

    errors = validate_password(data['password'])
    if errors:
        return jsonify({'error': 'Weak password', 'details': errors}), 400

    if User.query.filter_by(username=data['username']).first():
        return jsonify({'error': 'Username already exists'}), 409

    user = User(username=sanitize_string(data['username']), email=sanitize_string(data['email']), role='teacher', is_active=True)
    user.set_password(data['password'])
    db.session.add(user)
    db.session.flush()
    user._update_integrity_hash()

    teacher = Teacher(
        user_id=user.id,
        teacher_id=sanitize_string(data['teacher_id']),
        first_name=sanitize_string(data['first_name']),
        last_name=sanitize_string(data['last_name']),
        email=sanitize_string(data['email']),
        phone=sanitize_string(data.get('phone', '')),
        department_id=data.get('department_id'),
        specialization=sanitize_string(data.get('specialization', '')),
        qualification=sanitize_string(data.get('qualification', ''))
    )
    teacher.update_integrity_hash()
    db.session.add(teacher)
    db.session.commit()

    log_action('TEACHER_CREATED', username=me.username, user_id=me.id, resource='Teacher', resource_id=teacher.id, ip_address=ip)
    return jsonify({'message': 'Teacher created', 'teacher': teacher.to_dict()}), 201


@admin_bp.route('/teachers/<int:tid>', methods=['GET'])
@admin_required
def get_teacher(tid):
    teacher = Teacher.query.get_or_404(tid)
    return jsonify({'teacher': teacher.to_dict()}), 200


@admin_bp.route('/teachers/<int:tid>', methods=['PUT'])
@admin_required
def update_teacher(tid):
    teacher = Teacher.query.get_or_404(tid)
    data = request.get_json()
    me = get_current_user()
    ip = get_ip_address(request)
    for f in ['first_name', 'last_name', 'phone', 'department_id', 'specialization', 'qualification']:
        if f in data:
            setattr(teacher, f, data[f])
    teacher.update_integrity_hash()
    db.session.commit()
    log_action('TEACHER_UPDATED', username=me.username, user_id=me.id, resource='Teacher', resource_id=tid, ip_address=ip)
    return jsonify({'message': 'Teacher updated', 'teacher': teacher.to_dict()}), 200


@admin_bp.route('/teachers/<int:tid>', methods=['DELETE'])
@admin_required
def delete_teacher(tid):
    teacher = Teacher.query.get_or_404(tid)
    me = get_current_user()
    ip = get_ip_address(request)
    user = User.query.get(teacher.user_id)
    db.session.delete(teacher)
    if user:
        db.session.delete(user)
    db.session.commit()
    log_action('TEACHER_DELETED', username=me.username, user_id=me.id, resource='Teacher', resource_id=tid, ip_address=ip)
    return jsonify({'message': 'Teacher deleted'}), 200


# ── Departments ────────────────────────────────────────────────────────────
@admin_bp.route('/departments', methods=['GET'])
@admin_required
def get_departments():
    depts = Department.query.all()
    return jsonify({'departments': [d.to_dict() for d in depts]}), 200


@admin_bp.route('/departments', methods=['POST'])
@admin_required
def create_department():
    data = request.get_json()
    me = get_current_user()
    ip = get_ip_address(request)
    if not data.get('name') or not data.get('code'):
        return jsonify({'error': 'Name and code required'}), 400
    if Department.query.filter_by(code=data['code']).first():
        return jsonify({'error': 'Department code already exists'}), 409
    dept = Department(
        name=sanitize_string(data['name']),
        code=sanitize_string(data['code']).upper(),
        description=sanitize_string(data.get('description', ''), 500),
        head_name=sanitize_string(data.get('head_name', ''))
    )
    db.session.add(dept)
    db.session.commit()
    log_action('DEPARTMENT_CREATED', username=me.username, user_id=me.id, resource='Department', resource_id=dept.id, ip_address=ip)
    return jsonify({'message': 'Department created', 'department': dept.to_dict()}), 201


@admin_bp.route('/departments/<int:did>', methods=['PUT'])
@admin_required
def update_department(did):
    dept = Department.query.get_or_404(did)
    data = request.get_json()
    me = get_current_user()
    ip = get_ip_address(request)
    for f in ['name', 'description', 'head_name']:
        if f in data:
            setattr(dept, f, sanitize_string(data[f]))
    db.session.commit()
    log_action('DEPARTMENT_UPDATED', username=me.username, user_id=me.id, resource='Department', resource_id=did, ip_address=ip)
    return jsonify({'message': 'Department updated', 'department': dept.to_dict()}), 200


@admin_bp.route('/departments/<int:did>', methods=['DELETE'])
@admin_required
def delete_department(did):
    dept = Department.query.get_or_404(did)
    me = get_current_user()
    ip = get_ip_address(request)
    db.session.delete(dept)
    db.session.commit()
    log_action('DEPARTMENT_DELETED', username=me.username, user_id=me.id, resource='Department', resource_id=did, ip_address=ip)
    return jsonify({'message': 'Department deleted'}), 200


# ── Courses ────────────────────────────────────────────────────────────────
@admin_bp.route('/courses', methods=['GET'])
@admin_required
def get_courses():
    courses = Course.query.all()
    return jsonify({'courses': [c.to_dict() for c in courses]}), 200


@admin_bp.route('/courses', methods=['POST'])
@admin_required
def create_course():
    data = request.get_json()
    me = get_current_user()
    ip = get_ip_address(request)
    if not data.get('code') or not data.get('name'):
        return jsonify({'error': 'Code and name required'}), 400
    if Course.query.filter_by(code=data['code']).first():
        return jsonify({'error': 'Course code already exists'}), 409
    course = Course(
        code=sanitize_string(data['code']).upper(),
        name=sanitize_string(data['name']),
        description=sanitize_string(data.get('description', ''), 500),
        credit_hours=data.get('credit_hours', 3),
        department_id=data.get('department_id'),
        teacher_id=data.get('teacher_id'),
        semester=sanitize_string(data.get('semester', ''))
    )
    db.session.add(course)
    db.session.commit()
    log_action('COURSE_CREATED', username=me.username, user_id=me.id, resource='Course', resource_id=course.id, ip_address=ip)
    return jsonify({'message': 'Course created', 'course': course.to_dict()}), 201


@admin_bp.route('/courses/<int:cid>', methods=['PUT'])
@admin_required
def update_course(cid):
    course = Course.query.get_or_404(cid)
    data = request.get_json()
    me = get_current_user()
    ip = get_ip_address(request)
    for f in ['name', 'description', 'credit_hours', 'department_id', 'teacher_id', 'semester', 'is_active']:
        if f in data:
            setattr(course, f, data[f])
    db.session.commit()
    log_action('COURSE_UPDATED', username=me.username, user_id=me.id, resource='Course', resource_id=cid, ip_address=ip)
    return jsonify({'message': 'Course updated', 'course': course.to_dict()}), 200


@admin_bp.route('/courses/<int:cid>', methods=['DELETE'])
@admin_required
def delete_course(cid):
    course = Course.query.get_or_404(cid)
    me = get_current_user()
    ip = get_ip_address(request)
    db.session.delete(course)
    db.session.commit()
    log_action('COURSE_DELETED', username=me.username, user_id=me.id, resource='Course', resource_id=cid, ip_address=ip)
    return jsonify({'message': 'Course deleted'}), 200


@admin_bp.route('/courses/<int:cid>/enroll', methods=['POST'])
@admin_required
def enroll_student(cid):
    data = request.get_json()
    me = get_current_user()
    ip = get_ip_address(request)
    student_id = data.get('student_id')
    student = Student.query.get_or_404(student_id)
    existing = Enrollment.query.filter_by(student_id=student_id, course_id=cid).first()
    if existing:
        return jsonify({'error': 'Student already enrolled'}), 409
    enrollment = Enrollment(student_id=student_id, course_id=cid, status='active')
    db.session.add(enrollment)
    db.session.commit()
    log_action('STUDENT_ENROLLED', username=me.username, user_id=me.id, resource='Enrollment', resource_id=enrollment.id, ip_address=ip)
    return jsonify({'message': 'Student enrolled', 'enrollment': enrollment.to_dict()}), 201


# ── Audit Logs ─────────────────────────────────────────────────────────────
@admin_bp.route('/audit-logs', methods=['GET'])
@admin_required
def get_audit_logs():
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 50, type=int)
    logs = AuditLog.query.order_by(AuditLog.timestamp.desc()).paginate(page=page, per_page=per_page)
    return jsonify({
        'logs': [l.to_dict() for l in logs.items],
        'total': logs.total,
        'pages': logs.pages,
        'current_page': logs.page
    }), 200


# ── Security Center ────────────────────────────────────────────────────────
@admin_bp.route('/security/locked-accounts', methods=['GET'])
@admin_required
def get_locked_accounts():
    from datetime import datetime, timezone
    locked = User.query.filter(User.lock_until != None).all()
    result = []
    for u in locked:
        remaining = 0
        if u.lock_until:
            diff = (u.lock_until.replace(tzinfo=timezone.utc) - datetime.now(timezone.utc)).total_seconds()
            remaining = max(0, int(diff))
        result.append({**u.to_dict(), 'remaining_lockout': remaining})
    return jsonify({'locked_accounts': result}), 200


@admin_bp.route('/security/integrity-report', methods=['GET'])
@admin_required
def integrity_report():
    students = Student.query.all()
    teachers = Teacher.query.all()
    users = User.query.all()
    report = {
        'students': [{'id': s.id, 'name': f"{s.first_name} {s.last_name}", 'student_id': s.student_id,
                      'integrity': s.verify_integrity()} for s in students],
        'teachers': [{'id': t.id, 'name': f"{t.first_name} {t.last_name}", 'teacher_id': t.teacher_id,
                      'integrity': t.verify_integrity()} for t in teachers],
        'users': [{'id': u.id, 'username': u.username, 'integrity': u.verify_integrity()} for u in users],
    }
    tampered = sum(1 for s in report['students'] if s['integrity'] == 'TAMPERED') + \
               sum(1 for t in report['teachers'] if t['integrity'] == 'TAMPERED') + \
               sum(1 for u in report['users'] if u['integrity'] == 'TAMPERED')
    report['summary'] = {'total_checked': len(students) + len(teachers) + len(users), 'tampered': tampered}
    return jsonify({'report': report}), 200


@admin_bp.route('/security/failed-logins', methods=['GET'])
@admin_required
def get_failed_logins():
    logs = AuditLog.query.filter(
        AuditLog.action.in_(['LOGIN_FAILED', 'ACCOUNT_LOCKED', 'LOGIN_BLOCKED'])
    ).order_by(AuditLog.timestamp.desc()).limit(100).all()
    return jsonify({'logs': [l.to_dict() for l in logs]}), 200

@admin_bp.route('/notifications', methods=['GET'])
@admin_required
def get_all_notifications():
    notifs = Notification.query.order_by(Notification.created_at.desc()).limit(100).all()
    return jsonify({'notifications': [n.to_dict() for n in notifs]}), 200


@admin_bp.route('/notifications', methods=['POST'])
@admin_required
def send_notification():
    data = request.get_json()
    me = get_current_user()
    ip = get_ip_address(request)

    title = sanitize_string(data.get('title', ''), 200)
    message = sanitize_string(data.get('message', ''), 1000)
    recipient_id = data.get('recipient_id')
    broadcast = data.get('broadcast', False)
    notif_type = data.get('type', 'info')

    if not title or not message:
        return jsonify({'error': 'title and message required'}), 400

    sent = 0
    if broadcast:
        # Send to all active users
        users = User.query.filter_by(is_active=True).all()
        for u in users:
            if u.id == me.id:
                continue
            n = Notification(
                recipient_id=u.id, sender_id=me.id,
                title=title, message=message, type=notif_type
            )
            db.session.add(n)
            sent += 1
    elif recipient_id:
        n = Notification(
            recipient_id=recipient_id, sender_id=me.id,
            title=title, message=message, type=notif_type
        )
        db.session.add(n)
        sent = 1
    else:
        return jsonify({'error': 'recipient_id or broadcast=true required'}), 400

    db.session.commit()
    log_action('NOTIFICATION_SENT', username=me.username, user_id=me.id,
               ip_address=ip, details=f'{sent} notification(s) sent')
    return jsonify({'message': f'{sent} notification(s) sent'}), 201


@admin_bp.route('/notifications/<int:nid>', methods=['DELETE'])
@admin_required
def delete_notification(nid):
    notif = Notification.query.get_or_404(nid)
    db.session.delete(notif)
    db.session.commit()
    return jsonify({'message': 'Notification deleted'}), 200
