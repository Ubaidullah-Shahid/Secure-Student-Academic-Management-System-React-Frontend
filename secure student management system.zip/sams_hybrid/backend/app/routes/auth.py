# app/routes/auth.py  (REPLACE existing file)
from flask import Blueprint, request, jsonify
from flask_jwt_extended import (
    create_access_token, create_refresh_token,
    jwt_required, get_jwt_identity, get_jwt
)
from app import db, limiter
from app.models.user import User
from app.models.token_blocklist import TokenBlocklist
from app.utils.audit import log_action
from app.utils.security import validate_password, get_ip_address
from datetime import datetime, timezone, timedelta

auth_bp = Blueprint('auth', __name__)


@auth_bp.route('/login', methods=['POST'])
@limiter.limit("10 per minute")
def login():
    data = request.get_json()
    if not data:
        return jsonify({'error': 'No data provided'}), 400

    username = data.get('username', '').strip()
    password = data.get('password', '')
    ip = get_ip_address(request)

    if not username or not password:
        return jsonify({'error': 'Username and password required'}), 400

    user = User.query.filter_by(username=username).first()

    if not user:
        log_action('LOGIN_FAILED', username=username, ip_address=ip, status='FAILED',
                   details='User not found')
        return jsonify({'error': 'Invalid credentials'}), 401

    if not user.is_active:
        return jsonify({'error': 'Account is deactivated. Contact admin.'}), 403

    if user.is_locked():
        remaining = int((user.lock_until.replace(tzinfo=timezone.utc) - datetime.now(timezone.utc)).total_seconds())
        log_action('LOGIN_BLOCKED', username=username, user_id=user.id, ip_address=ip,
                   status='BLOCKED', details=f'Account locked. {remaining}s remaining')
        return jsonify({
            'error': f'Account locked. Try again in {remaining} seconds.',
            'locked': True, 'remaining': remaining
        }), 429

    if not user.check_password(password):
        user.failed_attempts += 1
        if user.failed_attempts >= 5:
            user.lock_until = datetime.now(timezone.utc) + timedelta(seconds=60)
            db.session.commit()
            log_action('ACCOUNT_LOCKED', username=username, user_id=user.id, ip_address=ip,
                       status='LOCKED', details=f'Locked after {user.failed_attempts} failed attempts')
            return jsonify({
                'error': 'Account locked for 60 seconds due to too many failed attempts.',
                'locked': True, 'remaining': 60
            }), 429
        db.session.commit()
        remaining_attempts = 5 - user.failed_attempts
        log_action('LOGIN_FAILED', username=username, user_id=user.id, ip_address=ip,
                   status='FAILED', details=f'Wrong password. {user.failed_attempts} failed attempts')
        return jsonify({'error': f'Invalid credentials. {remaining_attempts} attempts remaining.'}), 401

    user.failed_attempts = 0
    user.lock_until = None
    user.last_login = datetime.now(timezone.utc)
    db.session.commit()

    access_token = create_access_token(identity=str(user.id))
    refresh_token = create_refresh_token(identity=str(user.id))

    log_action('LOGIN_SUCCESS', username=username, user_id=user.id, ip_address=ip, status='SUCCESS')

    return jsonify({
        'access_token': access_token,
        'refresh_token': refresh_token,
        'user': user.to_dict()
    }), 200


@auth_bp.route('/refresh', methods=['POST'])
@jwt_required(refresh=True)
def refresh():
    user_id = int(get_jwt_identity())
    user = User.query.get(int(user_id))
    if not user or not user.is_active:
        return jsonify({'error': 'User not found or inactive'}), 404

    # Blacklist old refresh token
    jti = get_jwt()['jti']
    old_token = TokenBlocklist(jti=jti, token_type='refresh', user_id=int(user_id))
    db.session.add(old_token)
    db.session.commit()

    access_token = create_access_token(identity=str(user_id))
    new_refresh = create_refresh_token(identity=str(user_id))
    return jsonify({'access_token': access_token, 'refresh_token': new_refresh}), 200


@auth_bp.route('/logout', methods=['POST'])
@jwt_required()
def logout():
    user_id = int(get_jwt_identity())
    user = User.query.get(int(user_id))
    ip = get_ip_address(request)
    jti = get_jwt()['jti']

    # Blacklist the access token — proper logout
    blocked = TokenBlocklist(jti=jti, token_type='access', user_id=int(user_id))
    db.session.add(blocked)
    db.session.commit()

    log_action('LOGOUT', username=user.username if user else 'unknown',
               user_id=user_id, ip_address=ip, status='SUCCESS')
    return jsonify({'message': 'Logged out successfully'}), 200


@auth_bp.route('/me', methods=['GET'])
@jwt_required()
def get_me():
    user_id = int(get_jwt_identity())
    user = User.query.get(int(user_id))
    if not user:
        return jsonify({'error': 'User not found'}), 404
    return jsonify({'user': user.to_dict()}), 200


@auth_bp.route('/change-password', methods=['POST'])
@jwt_required()
def change_password():
    user_id = int(get_jwt_identity())
    user = User.query.get(int(user_id))
    data = request.get_json()
    ip = get_ip_address(request)

    current_password = data.get('current_password', '')
    new_password = data.get('new_password', '')

    if not user.check_password(current_password):
        return jsonify({'error': 'Current password is incorrect'}), 400

    errors = validate_password(new_password)
    if errors:
        return jsonify({'error': 'Password too weak', 'details': errors}), 400

    user.set_password(new_password)
    user._update_integrity_hash()
    db.session.commit()

    log_action('PASSWORD_CHANGED', username=user.username, user_id=user_id,
               ip_address=ip, status='SUCCESS')
    return jsonify({'message': 'Password changed successfully'}), 200
