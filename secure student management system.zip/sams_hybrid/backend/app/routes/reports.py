# app/routes/reports.py  (NEW FILE)
from flask import Blueprint, request, jsonify
from flask_jwt_extended import get_jwt_identity
from app import db
from app.models.user import User
from app.models.student import Student
from app.models.teacher import Teacher
from app.models.course import Course
from app.models.attendance import Attendance
from app.models.grade import Grade
from app.models.audit_log import AuditLog
from app.models.enrollment import Enrollment
from app.middleware.auth_middleware import admin_required, teacher_required
from datetime import datetime, timezone

reports_bp = Blueprint('reports', __name__)


def get_current_user():
    return User.query.get(int(get_jwt_identity()))


# ── Student Report ──────────────────────────────────────────────────────────
@reports_bp.route('/students', methods=['GET'])
@admin_required
def student_report():
    """Complete student report: enrollment, CGPA, attendance summary."""
    students = Student.query.filter_by(is_active=True).all()
    report = []
    for s in students:
        enrollments = Enrollment.query.filter_by(student_id=s.id, status='active').count()
        grades = Grade.query.filter_by(student_id=s.id).all()
        cgpa = round(sum(g.grade_points for g in grades) / len(grades), 2) if grades else 0.0
        total_att = Attendance.query.filter_by(student_id=s.id).count()
        present_att = Attendance.query.filter_by(student_id=s.id, status='present').count()
        att_pct = round(present_att / total_att * 100, 1) if total_att > 0 else 0.0
        report.append({
            'student_id': s.student_id,
            'full_name': f"{s.first_name} {s.last_name}",
            'email': s.email,
            'department': s.department.name if s.department else 'N/A',
            'semester': s.semester,
            'enrolled_courses': enrollments,
            'cgpa': cgpa,
            'attendance_percentage': att_pct,
            'integrity_status': s.verify_integrity()
        })
    return jsonify({'report': report, 'total': len(report),
                    'generated_at': datetime.now(timezone.utc).isoformat()}), 200


# ── Teacher Report ──────────────────────────────────────────────────────────
@reports_bp.route('/teachers', methods=['GET'])
@admin_required
def teacher_report():
    """Teacher workload report: courses assigned and student count."""
    teachers = Teacher.query.filter_by(is_active=True).all()
    report = []
    for t in teachers:
        courses = Course.query.filter_by(teacher_id=t.id).all()
        total_students = sum(
            Enrollment.query.filter_by(course_id=c.id, status='active').count()
            for c in courses
        )
        report.append({
            'teacher_id': t.teacher_id,
            'full_name': f"{t.first_name} {t.last_name}",
            'email': t.email,
            'department': t.department.name if t.department else 'N/A',
            'courses_assigned': len(courses),
            'course_names': [c.name for c in courses],
            'total_students': total_students
        })
    return jsonify({'report': report, 'total': len(report),
                    'generated_at': datetime.now(timezone.utc).isoformat()}), 200


# ── Attendance Report ───────────────────────────────────────────────────────
@reports_bp.route('/attendance', methods=['GET'])
@admin_required
def attendance_report():
    """System-wide attendance report per course."""
    courses = Course.query.all()
    report = []
    for c in courses:
        enrollments = Enrollment.query.filter_by(course_id=c.id, status='active').all()
        course_data = {
            'course_code': c.code,
            'course_name': c.name,
            'teacher': f"{c.teacher.first_name} {c.teacher.last_name}" if c.teacher else 'N/A',
            'enrolled_students': len(enrollments),
            'students': []
        }
        for enr in enrollments:
            s = enr.student
            if not s:
                continue
            total = Attendance.query.filter_by(student_id=s.id, course_id=c.id).count()
            present = Attendance.query.filter_by(student_id=s.id, course_id=c.id, status='present').count()
            pct = round(present / total * 100, 1) if total > 0 else 0.0
            course_data['students'].append({
                'student_id': s.student_id,
                'name': f"{s.first_name} {s.last_name}",
                'total_classes': total,
                'present': present,
                'absent': total - present,
                'percentage': pct,
                'status': 'OK' if pct >= 75 else 'LOW'
            })
        report.append(course_data)
    return jsonify({'report': report, 'generated_at': datetime.now(timezone.utc).isoformat()}), 200


# ── Grade Report ────────────────────────────────────────────────────────────
@reports_bp.route('/grades', methods=['GET'])
@admin_required
def grade_report():
    """System-wide grade distribution report."""
    courses = Course.query.all()
    report = []
    for c in courses:
        grades = Grade.query.filter_by(course_id=c.id).all()
        if not grades:
            continue
        dist = {'A+': 0, 'A': 0, 'A-': 0, 'B+': 0, 'B': 0, 'B-': 0,
                'C+': 0, 'C': 0, 'C-': 0, 'D': 0, 'F': 0}
        total_points = 0
        for g in grades:
            if g.grade_letter in dist:
                dist[g.grade_letter] += 1
            total_points += g.grade_points
        avg_gpa = round(total_points / len(grades), 2) if grades else 0.0
        report.append({
            'course_code': c.code,
            'course_name': c.name,
            'teacher': f"{c.teacher.first_name} {c.teacher.last_name}" if c.teacher else 'N/A',
            'total_graded': len(grades),
            'average_gpa': avg_gpa,
            'grade_distribution': dist
        })
    return jsonify({'report': report, 'generated_at': datetime.now(timezone.utc).isoformat()}), 200


# ── Security Report ─────────────────────────────────────────────────────────
@reports_bp.route('/security', methods=['GET'])
@admin_required
def security_report():
    """Security event summary report."""
    from app.models.user import User
    total_users = User.query.count()
    active_users = User.query.filter_by(is_active=True).count()
    locked_users = User.query.filter(User.lock_until != None).count()
    failed_logins = AuditLog.query.filter_by(action='LOGIN_FAILED').count()
    successful_logins = AuditLog.query.filter_by(action='LOGIN_SUCCESS').count()
    account_locks = AuditLog.query.filter_by(action='ACCOUNT_LOCKED').count()
    recent_security_events = AuditLog.query.filter(
        AuditLog.action.in_(['LOGIN_FAILED', 'ACCOUNT_LOCKED', 'LOGIN_BLOCKED', 'PASSWORD_CHANGED'])
    ).order_by(AuditLog.timestamp.desc()).limit(20).all()

    # Integrity check
    students = Student.query.all()
    integrity_summary = {'VALID': 0, 'TAMPERED': 0, 'UNVERIFIED': 0}
    for s in students:
        status = s.verify_integrity()
        integrity_summary[status] = integrity_summary.get(status, 0) + 1

    users = User.query.all()
    for u in users:
        status = u.verify_integrity()
        integrity_summary[status] = integrity_summary.get(status, 0) + 1

    return jsonify({
        'summary': {
            'total_users': total_users,
            'active_users': active_users,
            'locked_accounts': locked_users,
            'total_failed_logins': failed_logins,
            'total_successful_logins': successful_logins,
            'total_account_locks': account_locks
        },
        'integrity': integrity_summary,
        'recent_events': [e.to_dict() for e in recent_security_events],
        'generated_at': datetime.now(timezone.utc).isoformat()
    }), 200


# ── Teacher-accessible: class performance ──────────────────────────────────
@reports_bp.route('/class-performance/<int:course_id>', methods=['GET'])
@teacher_required
def class_performance(course_id):
    """Per-course class performance report for teachers."""
    course = Course.query.get_or_404(course_id)
    enrollments = Enrollment.query.filter_by(course_id=course_id, status='active').all()
    data = []
    for enr in enrollments:
        s = enr.student
        if not s:
            continue
        grade = Grade.query.filter_by(student_id=s.id, course_id=course_id).first()
        total_att = Attendance.query.filter_by(student_id=s.id, course_id=course_id).count()
        present_att = Attendance.query.filter_by(student_id=s.id, course_id=course_id, status='present').count()
        att_pct = round(present_att / total_att * 100, 1) if total_att > 0 else 0.0
        data.append({
            'roll_no': s.student_id,
            'name': f"{s.first_name} {s.last_name}",
            'attendance_pct': att_pct,
            'midterm': grade.midterm_marks if grade else 0,
            'final': grade.final_marks if grade else 0,
            'assignment': grade.assignment_marks if grade else 0,
            'quiz': grade.quiz_marks if grade else 0,
            'total': grade.total_marks if grade else 0,
            'grade': grade.grade_letter if grade else 'N/A',
            'gpa': grade.grade_points if grade else 0
        })
    return jsonify({
        'course': course.name,
        'course_code': course.code,
        'students': data,
        'total_enrolled': len(data),
        'generated_at': datetime.now(timezone.utc).isoformat()
    }), 200
