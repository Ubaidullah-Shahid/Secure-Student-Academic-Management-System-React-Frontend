from flask import Blueprint, request, jsonify
from flask_jwt_extended import get_jwt_identity
from app import db
from app.models.user import User
from app.models.student import Student
from app.models.course import Course
from app.models.enrollment import Enrollment
from app.models.attendance import Attendance
from app.models.grade import Grade
from app.models.assignment import Assignment, AssignmentSubmission
from app.models.audit_log import AuditLog
from app.models.notification import Notification
from app.middleware.auth_middleware import student_required
from app.utils.security import sanitize_string, get_ip_address
from datetime import datetime

student_bp = Blueprint('student', __name__)


def get_current_user():
    return User.query.get(int(get_jwt_identity()))


def get_current_student():
    user = get_current_user()
    if not user:
        return None
    return Student.query.filter_by(user_id=user.id).first()


@student_bp.route('/dashboard', methods=['GET'])
@student_required
def dashboard():
    student = get_current_student()
    if not student:
        return jsonify({'error': 'Student profile not found'}), 404

    enrollments = Enrollment.query.filter_by(student_id=student.id, status='active').all()
    total_courses = len(enrollments)

    total_present = 0
    total_classes = 0
    for enr in enrollments:
        classes = Attendance.query.filter_by(student_id=student.id, course_id=enr.course_id).count()
        present = Attendance.query.filter_by(student_id=student.id, course_id=enr.course_id, status='present').count()
        total_classes += classes
        total_present += present

    att_pct = round((total_present / total_classes * 100), 1) if total_classes > 0 else 0

    grades = Grade.query.filter_by(student_id=student.id).all()
    cgpa = round(sum(g.grade_points for g in grades) / len(grades), 2) if grades else 0.0

    notifications = Notification.query.filter_by(recipient_id=get_jwt_identity(), is_read=False).count()
    login_history = AuditLog.query.filter_by(user_id = int(get_jwt_identity()), action='LOGIN_SUCCESS').order_by(
        AuditLog.timestamp.desc()).limit(5).all()

    return jsonify({
        'student': student.to_dict(),
        'stats': {
            'total_courses': total_courses,
            'attendance_percentage': att_pct,
            'cgpa': cgpa,
            'unread_notifications': notifications
        },
        'login_history': [l.to_dict() for l in login_history]
    }), 200


@student_bp.route('/profile', methods=['GET'])
@student_required
def get_profile():
    student = get_current_student()
    if not student:
        return jsonify({'error': 'Profile not found'}), 404
    return jsonify({'student': student.to_dict()}), 200


@student_bp.route('/profile', methods=['PUT'])
@student_required
def update_profile():
    student = get_current_student()
    if not student:
        return jsonify({'error': 'Profile not found'}), 404
    data = request.get_json()
    for f in ['phone', 'address']:
        if f in data:
            setattr(student, f, sanitize_string(data[f]))
    student.update_integrity_hash()
    db.session.commit()
    return jsonify({'message': 'Profile updated', 'student': student.to_dict()}), 200


@student_bp.route('/courses', methods=['GET'])
@student_required
def get_my_courses():
    student = get_current_student()
    if not student:
        return jsonify({'error': 'Profile not found'}), 404
    enrollments = Enrollment.query.filter_by(student_id=student.id, status='active').all()
    courses = [e.course.to_dict() for e in enrollments if e.course]
    return jsonify({'courses': courses}), 200


@student_bp.route('/attendance', methods=['GET'])
@student_required
def get_my_attendance():
    student = get_current_student()
    if not student:
        return jsonify({'error': 'Profile not found'}), 404
    course_id = request.args.get('course_id', type=int)
    query = Attendance.query.filter_by(student_id=student.id)
    if course_id:
        query = query.filter_by(course_id=course_id)
    records = query.order_by(Attendance.date.desc()).all()

    summary = {}
    for rec in records:
        cid = rec.course_id
        if cid not in summary:
            summary[cid] = {'course_id': cid, 'course_name': rec.course.name if rec.course else 'Unknown',
                            'total': 0, 'present': 0, 'absent': 0}
        summary[cid]['total'] += 1
        if rec.status == 'present':
            summary[cid]['present'] += 1
        else:
            summary[cid]['absent'] += 1

    for cid in summary:
        t = summary[cid]['total']
        summary[cid]['percentage'] = round(summary[cid]['present'] / t * 100, 1) if t > 0 else 0

    return jsonify({'records': [r.to_dict() for r in records], 'summary': list(summary.values())}), 200


@student_bp.route('/grades', methods=['GET'])
@student_required
def get_my_grades():
    student = get_current_student()
    if not student:
        return jsonify({'error': 'Profile not found'}), 404
    grades = Grade.query.filter_by(student_id=student.id).all()
    gpa = round(sum(g.grade_points for g in grades) / len(grades), 2) if grades else 0.0
    return jsonify({'grades': [g.to_dict() for g in grades], 'cgpa': gpa}), 200


@student_bp.route('/assignments', methods=['GET'])
@student_required
def get_my_assignments():
    student = get_current_student()
    if not student:
        return jsonify({'error': 'Profile not found'}), 404
    enrollments = Enrollment.query.filter_by(student_id=student.id, status='active').all()
    course_ids = [e.course_id for e in enrollments]
    assignments = Assignment.query.filter(Assignment.course_id.in_(course_ids)).all()
    result = []
    for a in assignments:
        sub = AssignmentSubmission.query.filter_by(assignment_id=a.id, student_id=student.id).first()
        d = a.to_dict()
        d['submission'] = sub.to_dict() if sub else None
        d['submitted'] = sub is not None
        result.append(d)
    return jsonify({'assignments': result}), 200


@student_bp.route('/assignments/<int:aid>/submit', methods=['POST'])
@student_required
def submit_assignment(aid):
    student = get_current_student()
    if not student:
        return jsonify({'error': 'Profile not found'}), 404
    assignment = Assignment.query.get_or_404(aid)
    data = request.get_json()

    existing = AssignmentSubmission.query.filter_by(assignment_id=aid, student_id=student.id).first()
    if existing:
        return jsonify({'error': 'Assignment already submitted'}), 409

    sub = AssignmentSubmission(
        assignment_id=aid,
        student_id=student.id,
        content=sanitize_string(data.get('content', ''), 2000),
        status='submitted'
    )
    db.session.add(sub)
    db.session.commit()
    return jsonify({'message': 'Assignment submitted', 'submission': sub.to_dict()}), 201


@student_bp.route('/notifications', methods=['GET'])
@student_required
def get_notifications():
    user_id = int(get_jwt_identity())
    notifs = Notification.query.filter_by(recipient_id=user_id).order_by(Notification.created_at.desc()).all()
    return jsonify({'notifications': [n.to_dict() for n in notifs]}), 200


@student_bp.route('/notifications/<int:nid>/read', methods=['PUT'])
@student_required
def mark_read(nid):
    user_id = int(get_jwt_identity())
    notif = Notification.query.filter_by(id=nid, recipient_id=user_id).first_or_404()
    notif.is_read = True
    db.session.commit()
    return jsonify({'message': 'Marked as read'}), 200


@student_bp.route('/security/login-history', methods=['GET'])
@student_required
def login_history():
    user_id = int(get_jwt_identity())
    logs = AuditLog.query.filter_by(user_id=user_id).order_by(
        AuditLog.timestamp.desc()).limit(20).all()
    return jsonify({'logs': [l.to_dict() for l in logs]}), 200
