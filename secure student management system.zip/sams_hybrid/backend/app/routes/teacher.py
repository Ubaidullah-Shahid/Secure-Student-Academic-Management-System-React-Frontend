from flask import Blueprint, request, jsonify
from flask_jwt_extended import get_jwt_identity
from app import db
from app.models.user import User
from app.models.student import Student
from app.models.teacher import Teacher
from app.models.course import Course
from app.models.attendance import Attendance
from app.models.grade import Grade
from app.models.assignment import Assignment, AssignmentSubmission
from app.models.enrollment import Enrollment
from app.middleware.auth_middleware import teacher_required
from app.utils.audit import log_action
from app.utils.security import sanitize_string, get_ip_address
from datetime import datetime, date

teacher_bp = Blueprint('teacher', __name__)


def get_current_user():
    return User.query.get(int(get_jwt_identity()))


def get_current_teacher():
    user = get_current_user()
    if not user:
        return None
    return Teacher.query.filter_by(user_id=user.id).first()


@teacher_bp.route('/dashboard', methods=['GET'])
@teacher_required
def dashboard():
    teacher = get_current_teacher()
    if not teacher:
        return jsonify({'error': 'Teacher profile not found'}), 404
    courses = Course.query.filter_by(teacher_id=teacher.id).all()
    total_students = 0
    for course in courses:
        total_students += len(course.enrollments)
    return jsonify({
        'teacher': teacher.to_dict(),
        'stats': {
            'total_courses': len(courses),
            'total_students': total_students,
        },
        'courses': [c.to_dict() for c in courses]
    }), 200


@teacher_bp.route('/courses', methods=['GET'])
@teacher_required
def get_my_courses():
    teacher = get_current_teacher()
    if not teacher:
        return jsonify({'error': 'Teacher profile not found'}), 404
    courses = Course.query.filter_by(teacher_id=teacher.id).all()
    return jsonify({'courses': [c.to_dict() for c in courses]}), 200


@teacher_bp.route('/courses/<int:cid>/students', methods=['GET'])
@teacher_required
def get_course_students(cid):
    teacher = get_current_teacher()
    course = Course.query.get_or_404(cid)
    if teacher and course.teacher_id != teacher.id:
        user = get_current_user()
        if user.role != 'admin':
            return jsonify({'error': 'Access denied'}), 403
    enrollments = Enrollment.query.filter_by(course_id=cid, status='active').all()
    students = [e.student.to_dict() for e in enrollments if e.student]
    return jsonify({'students': students}), 200


# ── Attendance ─────────────────────────────────────────────────────────────
@teacher_bp.route('/attendance', methods=['GET'])
@teacher_required
def get_attendance():
    teacher = get_current_teacher()
    course_id = request.args.get('course_id', type=int)
    att_date = request.args.get('date')
    query = Attendance.query
    if course_id:
        query = query.filter_by(course_id=course_id)
    if att_date:
        query = query.filter_by(date=datetime.strptime(att_date, '%Y-%m-%d').date())
    records = query.all()
    return jsonify({'attendance': [a.to_dict() for a in records]}), 200


@teacher_bp.route('/attendance', methods=['POST'])
@teacher_required
def mark_attendance():
    data = request.get_json()
    me = get_current_user()
    ip = get_ip_address(request)
    records = data.get('records', [])
    att_date_str = data.get('date')
    course_id = data.get('course_id')

    if not records or not att_date_str or not course_id:
        return jsonify({'error': 'records, date, and course_id required'}), 400

    att_date = datetime.strptime(att_date_str, '%Y-%m-%d').date()
    saved = 0
    for rec in records:
        student_id = rec.get('student_id')
        status = rec.get('status', 'present')
        existing = Attendance.query.filter_by(student_id=student_id, course_id=course_id, date=att_date).first()
        if existing:
            existing.status = status
            existing.remarks = rec.get('remarks', '')
        else:
            att = Attendance(
                student_id=student_id,
                course_id=course_id,
                date=att_date,
                status=status,
                marked_by=me.id,
                remarks=rec.get('remarks', '')
            )
            db.session.add(att)
        saved += 1

    db.session.commit()
    log_action('ATTENDANCE_MARKED', username=me.username, user_id=me.id, resource='Attendance',
               resource_id=course_id, ip_address=ip, details=f'{saved} records for {att_date_str}')
    return jsonify({'message': f'{saved} attendance records saved'}), 200


@teacher_bp.route('/attendance/<int:aid>', methods=['PUT'])
@teacher_required
def update_attendance(aid):
    att = Attendance.query.get_or_404(aid)
    data = request.get_json()
    me = get_current_user()
    ip = get_ip_address(request)
    if 'status' in data:
        att.status = data['status']
    if 'remarks' in data:
        att.remarks = data['remarks']
    db.session.commit()
    log_action('ATTENDANCE_UPDATED', username=me.username, user_id=me.id, resource='Attendance', resource_id=aid, ip_address=ip)
    return jsonify({'message': 'Attendance updated', 'attendance': att.to_dict()}), 200


@teacher_bp.route('/attendance/report/<int:course_id>', methods=['GET'])
@teacher_required
def attendance_report(course_id):
    enrollments = Enrollment.query.filter_by(course_id=course_id, status='active').all()
    report = []
    for enr in enrollments:
        student = enr.student
        if not student:
            continue
        total = Attendance.query.filter_by(student_id=student.id, course_id=course_id).count()
        present = Attendance.query.filter_by(student_id=student.id, course_id=course_id, status='present').count()
        percentage = round((present / total * 100), 1) if total > 0 else 0
        report.append({
            'student_id': student.id,
            'student_name': f"{student.first_name} {student.last_name}",
            'roll_no': student.student_id,
            'total_classes': total,
            'present': present,
            'absent': total - present,
            'percentage': percentage
        })
    return jsonify({'report': report}), 200


# ── Grades ─────────────────────────────────────────────────────────────────
@teacher_bp.route('/grades', methods=['GET'])
@teacher_required
def get_grades():
    course_id = request.args.get('course_id', type=int)
    query = Grade.query
    if course_id:
        query = query.filter_by(course_id=course_id)
    grades = query.all()
    return jsonify({'grades': [g.to_dict() for g in grades]}), 200


@teacher_bp.route('/grades', methods=['POST'])
@teacher_required
def add_grade():
    data = request.get_json()
    me = get_current_user()
    ip = get_ip_address(request)
    required = ['student_id', 'course_id']
    for f in required:
        if not data.get(f):
            return jsonify({'error': f'{f} is required'}), 400

    existing = Grade.query.filter_by(
        student_id=data['student_id'],
        course_id=data['course_id'],
        semester=data.get('semester', 'Current')
    ).first()

    if existing:
        grade = existing
    else:
        grade = Grade(
            student_id=data['student_id'],
            course_id=data['course_id'],
            semester=data.get('semester', 'Current'),
            updated_by=me.id
        )
        db.session.add(grade)

    grade.midterm_marks = data.get('midterm_marks', grade.midterm_marks or 0)
    grade.final_marks = data.get('final_marks', grade.final_marks or 0)
    grade.assignment_marks = data.get('assignment_marks', grade.assignment_marks or 0)
    grade.quiz_marks = data.get('quiz_marks', grade.quiz_marks or 0)
    grade.remarks = data.get('remarks', grade.remarks)
    grade.calculate_grade()
    grade.updated_by = me.id

    db.session.commit()
    log_action('GRADE_UPDATED', username=me.username, user_id=me.id, resource='Grade',
               resource_id=grade.id, ip_address=ip)
    return jsonify({'message': 'Grade saved', 'grade': grade.to_dict()}), 200


# ── Assignments ────────────────────────────────────────────────────────────
@teacher_bp.route('/assignments', methods=['GET'])
@teacher_required
def get_assignments():
    teacher = get_current_teacher()
    course_id = request.args.get('course_id', type=int)
    query = Assignment.query
    if course_id:
        query = query.filter_by(course_id=course_id)
    else:
        if teacher:
            course_ids = [c.id for c in Course.query.filter_by(teacher_id=teacher.id).all()]
            query = query.filter(Assignment.course_id.in_(course_ids))
    assignments = query.all()
    return jsonify({'assignments': [a.to_dict() for a in assignments]}), 200


@teacher_bp.route('/assignments', methods=['POST'])
@teacher_required
def create_assignment():
    data = request.get_json()
    me = get_current_user()
    ip = get_ip_address(request)
    if not data.get('title') or not data.get('course_id'):
        return jsonify({'error': 'title and course_id required'}), 400

    deadline = None
    if data.get('deadline'):
        deadline = datetime.strptime(data['deadline'], '%Y-%m-%dT%H:%M')

    assignment = Assignment(
        course_id=data['course_id'],
        title=sanitize_string(data['title']),
        description=sanitize_string(data.get('description', ''), 1000),
        total_marks=data.get('total_marks', 100),
        deadline=deadline,
        created_by=me.id
    )
    db.session.add(assignment)
    db.session.commit()
    log_action('ASSIGNMENT_CREATED', username=me.username, user_id=me.id, resource='Assignment',
               resource_id=assignment.id, ip_address=ip)
    return jsonify({'message': 'Assignment created', 'assignment': assignment.to_dict()}), 201


@teacher_bp.route('/assignments/<int:aid>', methods=['PUT'])
@teacher_required
def update_assignment(aid):
    assignment = Assignment.query.get_or_404(aid)
    data = request.get_json()
    me = get_current_user()
    ip = get_ip_address(request)
    for f in ['title', 'description', 'total_marks']:
        if f in data:
            setattr(assignment, f, data[f])
    if data.get('deadline'):
        assignment.deadline = datetime.strptime(data['deadline'], '%Y-%m-%dT%H:%M')
    db.session.commit()
    log_action('ASSIGNMENT_UPDATED', username=me.username, user_id=me.id, resource='Assignment',
               resource_id=aid, ip_address=ip)
    return jsonify({'message': 'Assignment updated', 'assignment': assignment.to_dict()}), 200


@teacher_bp.route('/assignments/<int:aid>', methods=['DELETE'])
@teacher_required
def delete_assignment(aid):
    assignment = Assignment.query.get_or_404(aid)
    me = get_current_user()
    ip = get_ip_address(request)
    db.session.delete(assignment)
    db.session.commit()
    log_action('ASSIGNMENT_DELETED', username=me.username, user_id=me.id, resource='Assignment',
               resource_id=aid, ip_address=ip)
    return jsonify({'message': 'Assignment deleted'}), 200


@teacher_bp.route('/assignments/<int:aid>/submissions', methods=['GET'])
@teacher_required
def get_submissions(aid):
    subs = AssignmentSubmission.query.filter_by(assignment_id=aid).all()
    return jsonify({'submissions': [s.to_dict() for s in subs]}), 200


@teacher_bp.route('/submissions/<int:sid>/grade', methods=['PUT'])
@teacher_required
def grade_submission(sid):
    sub = AssignmentSubmission.query.get_or_404(sid)
    data = request.get_json()
    me = get_current_user()
    ip = get_ip_address(request)
    sub.marks_obtained = data.get('marks_obtained', sub.marks_obtained)
    sub.feedback = sanitize_string(data.get('feedback', ''), 500)
    sub.status = 'graded'
    db.session.commit()
    log_action('SUBMISSION_GRADED', username=me.username, user_id=me.id, resource='Submission',
               resource_id=sid, ip_address=ip)
    return jsonify({'message': 'Submission graded', 'submission': sub.to_dict()}), 200
