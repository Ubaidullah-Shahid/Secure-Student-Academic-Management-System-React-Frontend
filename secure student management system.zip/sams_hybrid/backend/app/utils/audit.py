from app import db
from app.models.audit_log import AuditLog
from datetime import datetime, timezone


def log_action(action, username=None, user_id=None, resource=None, resource_id=None,
               ip_address=None, status='SUCCESS', details=None):
    try:
        log = AuditLog(
            user_id=user_id,
            username=username,
            action=action,
            resource=resource,
            resource_id=str(resource_id) if resource_id else None,
            ip_address=ip_address,
            status=status,
            details=details,
            timestamp=datetime.now(timezone.utc)
        )
        db.session.add(log)
        db.session.commit()
    except Exception:
        db.session.rollback()
