from app import db, bcrypt
from app.models.user import User
from app.models.department import Department
from app.models.course import Course
from app.models.student import Student
from app.models.teacher import Teacher


def seed_default_admin():
    if User.query.filter_by(username='admin').first():
        return

    admin = User(
        username='admin',
        email='admin@sams.edu',
        role='admin',
        is_active=True
    )
    admin.set_password('Admin@1234')
    db.session.add(admin)
    db.session.flush()
    admin._update_integrity_hash()

    dept = Department(name='Computer Science', code='CS', description='CS Department', head_name='Dr. Admin')
    db.session.add(dept)
    db.session.flush()

    dept2 = Department(name='Information Technology', code='IT', description='IT Department', head_name='Dr. Smith')
    db.session.add(dept2)
    db.session.flush()

    teacher_user = User(username='teacher1', email='teacher1@sams.edu', role='teacher', is_active=True)
    teacher_user.set_password('Teacher@1234')
    db.session.add(teacher_user)
    db.session.flush()
    teacher_user._update_integrity_hash()

    teacher = Teacher(
        user_id=teacher_user.id,
        teacher_id='TCH-001',
        first_name='John',
        last_name='Smith',
        email='teacher1@sams.edu',
        department_id=dept.id,
        specialization='Information Security',
        qualification='PhD Computer Science'
    )
    teacher.update_integrity_hash()
    db.session.add(teacher)

    student_user = User(username='student1', email='student1@sams.edu', role='student', is_active=True)
    student_user.set_password('Student@1234')
    db.session.add(student_user)
    db.session.flush()
    student_user._update_integrity_hash()

    student = Student(
        user_id=student_user.id,
        student_id='STD-001',
        first_name='Alice',
        last_name='Johnson',
        email='student1@sams.edu',
        department_id=dept.id,
        semester=3,
        gender='Female'
    )
    student.update_integrity_hash()
    db.session.add(student)
    db.session.flush()

    course = Course(
        code='CS-401',
        name='Information Security',
        credit_hours=3,
        department_id=dept.id,
        semester='Fall 2024',
        description='Core IS concepts including cryptography, authentication, and security protocols'
    )
    db.session.add(course)

    db.session.commit()
