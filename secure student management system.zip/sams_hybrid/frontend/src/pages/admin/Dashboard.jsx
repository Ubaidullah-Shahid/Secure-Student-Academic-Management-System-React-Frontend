import React, { useEffect, useState } from 'react'
import { Grid, Card, CardContent, Typography, Box, Chip, Table, TableBody, TableCell, TableHead, TableRow, Paper, Alert } from '@mui/material'
import PeopleIcon from '@mui/icons-material/People'
import SchoolIcon from '@mui/icons-material/School'
import LibraryBooksIcon from '@mui/icons-material/LibraryBooks'
import BusinessIcon from '@mui/icons-material/Business'
import SecurityIcon from '@mui/icons-material/Security'
import ManageAccountsIcon from '@mui/icons-material/ManageAccounts'
import { adminAPI } from '../../services/api'

const StatCard = ({ title, value, icon, color }) => (
  <Card>
    <CardContent>
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <Box>
          <Typography variant="body2" color="text.secondary" gutterBottom>{title}</Typography>
          <Typography variant="h4" fontWeight={700} color={color}>{value}</Typography>
        </Box>
        <Box sx={{ p: 1.5, borderRadius: 2, bgcolor: `${color}15` }}>
          {React.cloneElement(icon, { sx: { fontSize: 32, color } })}
        </Box>
      </Box>
    </CardContent>
  </Card>
)

const statusColor = { SUCCESS: 'success', FAILED: 'error', BLOCKED: 'warning', LOCKED: 'error' }

export default function AdminDashboard() {
  const [data, setData] = useState(null)
  const [error, setError] = useState('')

  useEffect(() => {
    adminAPI.dashboard().then(r => setData(r.data)).catch(() => setError('Failed to load dashboard'))
  }, [])

  if (error) return <Alert severity="error">{error}</Alert>
  if (!data) return null

  const { stats, recent_logs } = data

  return (
    <Box>
      <Typography variant="h5" fontWeight={700} mb={3}>Admin Dashboard</Typography>
      <Grid container spacing={2} mb={4}>
        <Grid item xs={12} sm={6} md={4}><StatCard title="Total Students" value={stats.total_students} icon={<SchoolIcon />} color="#1565c0" /></Grid>
        <Grid item xs={12} sm={6} md={4}><StatCard title="Total Teachers" value={stats.total_teachers} icon={<PeopleIcon />} color="#00796b" /></Grid>
        <Grid item xs={12} sm={6} md={4}><StatCard title="Total Courses" value={stats.total_courses} icon={<LibraryBooksIcon />} color="#e65100" /></Grid>
        <Grid item xs={12} sm={6} md={4}><StatCard title="Departments" value={stats.total_departments} icon={<BusinessIcon />} color="#6a1b9a" /></Grid>
        <Grid item xs={12} sm={6} md={4}><StatCard title="Total Users" value={stats.total_users} icon={<ManageAccountsIcon />} color="#37474f" /></Grid>
        <Grid item xs={12} sm={6} md={4}><StatCard title="Locked Accounts" value={stats.locked_accounts} icon={<SecurityIcon />} color="#c62828" /></Grid>
      </Grid>

      <Typography variant="h6" fontWeight={600} mb={2}>Recent Security Events</Typography>
      <Paper>
        <Table size="small">
          <TableHead sx={{ bgcolor: '#f5f5f5' }}>
            <TableRow>
              <TableCell>Action</TableCell><TableCell>User</TableCell>
              <TableCell>IP Address</TableCell><TableCell>Status</TableCell><TableCell>Time</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {recent_logs.map(log => (
              <TableRow key={log.id} hover>
                <TableCell><Typography variant="body2" fontWeight={500}>{log.action}</Typography></TableCell>
                <TableCell>{log.username || '-'}</TableCell>
                <TableCell>{log.ip_address || '-'}</TableCell>
                <TableCell><Chip label={log.status} color={statusColor[log.status] || 'default'} size="small" /></TableCell>
                <TableCell><Typography variant="caption">{new Date(log.timestamp).toLocaleString()}</Typography></TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Paper>
    </Box>
  )
}
