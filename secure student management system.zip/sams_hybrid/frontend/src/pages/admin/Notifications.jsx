// frontend/src/pages/admin/Notifications.jsx  (NEW FILE)
import React, { useEffect, useState } from 'react'
import {
  Box, Typography, Paper, Button, TextField, Select, MenuItem,
  FormControl, InputLabel, CircularProgress, Alert, Snackbar,
  Table, TableHead, TableRow, TableCell, TableBody, TableContainer,
  Chip, Dialog, DialogTitle, DialogContent, DialogActions, Divider,
  FormControlLabel, Switch, IconButton, Tooltip
} from '@mui/material'
import NotificationsActiveIcon from '@mui/icons-material/NotificationsActive'
import AddIcon from '@mui/icons-material/Add'
import DeleteIcon from '@mui/icons-material/Delete'
import { adminAPI } from '../../services/api'
import api from '../../services/api'

export default function AdminNotifications() {
  const [notifications, setNotifications] = useState([])
  const [users, setUsers] = useState([])
  const [loading, setLoading] = useState(true)
  const [dialog, setDialog] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [toast, setToast] = useState({ open: false, msg: '', severity: 'success' })
  const [form, setForm] = useState({
    title: '', message: '', recipient_id: '', type: 'info', broadcast: false
  })

  const load = () => {
    setLoading(true)
    Promise.all([
      api.get('/admin/notifications'),
      adminAPI.getUsers()
    ])
      .then(([n, u]) => {
        setNotifications(n.data.notifications || [])
        setUsers(u.data.users || [])
      })
      .catch(() => setToast({ open: true, msg: 'Failed to load data', severity: 'error' }))
      .finally(() => setLoading(false))
  }

  useEffect(() => { load() }, [])

  const handleSend = async () => {
    if (!form.title.trim() || !form.message.trim()) {
      setToast({ open: true, msg: 'Title and message required', severity: 'error' })
      return
    }
    if (!form.broadcast && !form.recipient_id) {
      setToast({ open: true, msg: 'Select a recipient or enable broadcast', severity: 'error' })
      return
    }
    setSubmitting(true)
    try {
      await api.post('/admin/notifications', {
        title: form.title,
        message: form.message,
        type: form.type,
        recipient_id: form.broadcast ? undefined : parseInt(form.recipient_id),
        broadcast: form.broadcast
      })
      setToast({ open: true, msg: 'Notification sent successfully', severity: 'success' })
      setDialog(false)
      setForm({ title: '', message: '', recipient_id: '', type: 'info', broadcast: false })
      load()
    } catch {
      setToast({ open: true, msg: 'Failed to send notification', severity: 'error' })
    } finally {
      setSubmitting(false)
    }
  }

  const handleDelete = async (id) => {
    try {
      await api.delete(`/admin/notifications/${id}`)
      setNotifications(prev => prev.filter(n => n.id !== id))
      setToast({ open: true, msg: 'Notification deleted', severity: 'success' })
    } catch {
      setToast({ open: true, msg: 'Failed to delete', severity: 'error' })
    }
  }

  const typeColor = { info: 'info', warning: 'warning', success: 'success', error: 'error' }

  if (loading) return (
    <Box display="flex" justifyContent="center" alignItems="center" minHeight="50vh">
      <CircularProgress />
    </Box>
  )

  return (
    <Box>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Box display="flex" alignItems="center" gap={1.5}>
          <NotificationsActiveIcon sx={{ fontSize: 32, color: 'primary.main' }} />
          <Box>
            <Typography variant="h5">Notifications</Typography>
            <Typography variant="body2" color="text.secondary">
              Send and manage system notifications
            </Typography>
          </Box>
        </Box>
        <Button variant="contained" startIcon={<AddIcon />} onClick={() => setDialog(true)}>
          Send Notification
        </Button>
      </Box>

      <Paper variant="outlined">
        <TableContainer>
          <Table size="small">
            <TableHead sx={{ bgcolor: 'grey.50' }}>
              <TableRow>
                {['Title','Message','Type','Recipient','Sender','Sent At','Read','Action'].map(h => (
                  <TableCell key={h} sx={{ fontWeight: 600, fontSize: '0.78rem' }}>{h}</TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {notifications.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={8} align="center" sx={{ py: 4 }}>
                    <Typography color="text.secondary">No notifications sent yet</Typography>
                  </TableCell>
                </TableRow>
              ) : notifications.map(n => (
                <TableRow key={n.id} hover>
                  <TableCell>
                    <Typography variant="body2" fontWeight={500}>{n.title}</Typography>
                  </TableCell>
                  <TableCell>
                    <Typography variant="caption" color="text.secondary" sx={{
                      maxWidth: 200, display: 'block', overflow: 'hidden',
                      textOverflow: 'ellipsis', whiteSpace: 'nowrap'
                    }}>{n.message}</Typography>
                  </TableCell>
                  <TableCell>
                    <Chip label={n.type} size="small" color={typeColor[n.type] || 'default'} variant="outlined" />
                  </TableCell>
                  <TableCell>
                    <Typography variant="caption">{n.recipient_id}</Typography>
                  </TableCell>
                  <TableCell>{n.sender_name}</TableCell>
                  <TableCell>
                    <Typography variant="caption">{new Date(n.created_at).toLocaleString()}</Typography>
                  </TableCell>
                  <TableCell>
                    <Chip label={n.is_read ? 'Read' : 'Unread'} size="small"
                      color={n.is_read ? 'success' : 'default'} variant="outlined" />
                  </TableCell>
                  <TableCell>
                    <Tooltip title="Delete">
                      <IconButton size="small" color="error" onClick={() => handleDelete(n.id)}>
                        <DeleteIcon fontSize="small" />
                      </IconButton>
                    </Tooltip>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>

      {/* Send Dialog */}
      <Dialog open={dialog} onClose={() => setDialog(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Send Notification</DialogTitle>
        <Divider />
        <DialogContent sx={{ pt: 2 }}>
          <Box display="flex" flexDirection="column" gap={2}>
            <FormControlLabel
              control={
                <Switch checked={form.broadcast}
                  onChange={e => setForm(f => ({ ...f, broadcast: e.target.checked, recipient_id: '' }))} />
              }
              label="Broadcast to all active users"
            />
            {!form.broadcast && (
              <FormControl fullWidth size="small">
                <InputLabel>Recipient</InputLabel>
                <Select value={form.recipient_id} label="Recipient"
                  onChange={e => setForm(f => ({ ...f, recipient_id: e.target.value }))}>
                  <MenuItem value="">— Select User —</MenuItem>
                  {users.map(u => (
                    <MenuItem key={u.id} value={u.id}>
                      {u.username} ({u.role})
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            )}
            <FormControl fullWidth size="small">
              <InputLabel>Type</InputLabel>
              <Select value={form.type} label="Type"
                onChange={e => setForm(f => ({ ...f, type: e.target.value }))}>
                <MenuItem value="info">Info</MenuItem>
                <MenuItem value="warning">Warning</MenuItem>
                <MenuItem value="success">Success</MenuItem>
                <MenuItem value="error">Urgent</MenuItem>
              </Select>
            </FormControl>
            <TextField label="Title" size="small" fullWidth
              value={form.title}
              onChange={e => setForm(f => ({ ...f, title: e.target.value }))}
              inputProps={{ maxLength: 200 }} />
            <TextField label="Message" size="small" fullWidth multiline rows={4}
              value={form.message}
              onChange={e => setForm(f => ({ ...f, message: e.target.value }))}
              inputProps={{ maxLength: 1000 }}
              helperText={`${form.message.length}/1000`} />
          </Box>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={() => setDialog(false)}>Cancel</Button>
          <Button variant="contained" onClick={handleSend} disabled={submitting}>
            {submitting ? 'Sending…' : 'Send'}
          </Button>
        </DialogActions>
      </Dialog>

      <Snackbar open={toast.open} autoHideDuration={4000}
        onClose={() => setToast(t => ({ ...t, open: false }))}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}>
        <Alert severity={toast.severity} onClose={() => setToast(t => ({ ...t, open: false }))}>
          {toast.msg}
        </Alert>
      </Snackbar>
    </Box>
  )
}
