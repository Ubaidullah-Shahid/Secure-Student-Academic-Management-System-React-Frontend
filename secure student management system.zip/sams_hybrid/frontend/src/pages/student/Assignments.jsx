import React, { useEffect, useState } from 'react'
import { Box, Typography, Paper, Table, TableBody, TableCell, TableHead, TableRow, Chip, Button, Dialog, DialogTitle, DialogContent, DialogActions, TextField, Alert } from '@mui/material'
import AssignmentIcon from '@mui/icons-material/Assignment'
import { studentAPI } from '../../services/api'

export default function StudentAssignments() {
  const [assignments, setAssignments] = useState([])
  const [open, setOpen] = useState(false)
  const [selected, setSelected] = useState(null)
  const [content, setContent] = useState('')
  const [alert, setAlert] = useState({ msg: '', type: 'success' })

  const load = () => { studentAPI.getAssignments().then(r => setAssignments(r.data.assignments)) }
  useEffect(() => { load() }, [])

  const handleSubmit = async () => {
    try {
      await studentAPI.submitAssignment(selected.id, { content })
      setAlert({ msg: 'Assignment submitted successfully', type: 'success' })
      setOpen(false); setContent(''); load()
    } catch (e) { setAlert({ msg: e.response?.data?.error || 'Submission failed', type: 'error' }) }
  }

  const isOverdue = (deadline) => deadline && new Date(deadline) < new Date()

  const statusChip = (a) => {
    if (a.submitted) {
      const sub = a.submission
      if (sub?.status === 'graded') return <Chip label={`Graded: ${sub.marks_obtained}/${a.total_marks}`} color="success" size="small" />
      return <Chip label="Submitted" color="primary" size="small" />
    }
    if (isOverdue(a.deadline)) return <Chip label="Overdue" color="error" size="small" />
    return <Chip label="Pending" color="warning" size="small" />
  }

  return (
    <Box>
      <Typography variant="h5" fontWeight={700} mb={3}>My Assignments</Typography>
      {alert.msg && <Alert severity={alert.type} sx={{ mb: 2 }} onClose={() => setAlert({ msg: '', type: 'success' })}>{alert.msg}</Alert>}

      <Paper>
        <Table>
          <TableHead sx={{ bgcolor: '#0d1b3e' }}>
            <TableRow>
              <TableCell sx={{ color: '#fff' }}>Assignment</TableCell>
              <TableCell sx={{ color: '#fff' }}>Course</TableCell>
              <TableCell sx={{ color: '#fff' }}>Marks</TableCell>
              <TableCell sx={{ color: '#fff' }}>Deadline</TableCell>
              <TableCell sx={{ color: '#fff' }}>Status</TableCell>
              <TableCell sx={{ color: '#fff' }}>Action</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {assignments.map(a => (
              <TableRow key={a.id} hover sx={{ bgcolor: isOverdue(a.deadline) && !a.submitted ? 'rgba(198,40,40,0.04)' : 'inherit' }}>
                <TableCell>
                  <Box display="flex" alignItems="center" gap={1}>
                    <AssignmentIcon sx={{ color: '#1565c0', fontSize: 18 }} />
                    <Box>
                      <Typography fontWeight={500}>{a.title}</Typography>
                      {a.description && <Typography variant="caption" color="text.secondary" sx={{ display: 'block', maxWidth: 250, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{a.description}</Typography>}
                    </Box>
                  </Box>
                </TableCell>
                <TableCell><Chip label={a.course_code} size="small" color="secondary" /></TableCell>
                <TableCell>{a.total_marks}</TableCell>
                <TableCell>
                  {a.deadline ? (
                    <Typography variant="body2" color={isOverdue(a.deadline) ? 'error.main' : 'text.primary'}>
                      {new Date(a.deadline).toLocaleString()}
                    </Typography>
                  ) : '-'}
                </TableCell>
                <TableCell>{statusChip(a)}</TableCell>
                <TableCell>
                  {!a.submitted && !isOverdue(a.deadline) && (
                    <Button size="small" variant="outlined" onClick={() => { setSelected(a); setOpen(true) }}>
                      Submit
                    </Button>
                  )}
                  {a.submitted && a.submission?.feedback && (
                    <Typography variant="caption" color="success.main">Feedback: {a.submission.feedback}</Typography>
                  )}
                </TableCell>
              </TableRow>
            ))}
            {assignments.length === 0 && (
              <TableRow><TableCell colSpan={6} align="center"><Typography py={3} color="text.secondary">No assignments found</Typography></TableCell></TableRow>
            )}
          </TableBody>
        </Table>
      </Paper>

      <Dialog open={open} onClose={() => setOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Submit Assignment: {selected?.title}</DialogTitle>
        <DialogContent>
          <Typography variant="body2" color="text.secondary" mb={2}>
            {selected?.course_name} • Deadline: {selected?.deadline ? new Date(selected.deadline).toLocaleString() : 'N/A'}
          </Typography>
          <TextField fullWidth label="Your Answer / Submission" multiline rows={6} value={content}
            onChange={e => setContent(e.target.value)} required
            helperText="Enter your assignment response or solution here" />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpen(false)}>Cancel</Button>
          <Button variant="contained" onClick={handleSubmit} disabled={!content.trim()}>Submit Assignment</Button>
        </DialogActions>
      </Dialog>
    </Box>
  )
}
