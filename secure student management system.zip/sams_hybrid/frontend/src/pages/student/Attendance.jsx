import React, { useEffect, useState } from 'react'
import { Box, Typography, Paper, Table, TableBody, TableCell, TableHead, TableRow, Chip, Grid, Card, CardContent, LinearProgress, FormControl, InputLabel, Select, MenuItem } from '@mui/material'
import { studentAPI } from '../../services/api'

export default function StudentAttendance() {
  const [records, setRecords] = useState([])
  const [summary, setSummary] = useState([])
  const [courses, setCourses] = useState([])
  const [selectedCourse, setSelectedCourse] = useState('')

  useEffect(() => {
    studentAPI.getCourses().then(r => setCourses(r.data.courses))
    loadAttendance()
  }, [])

  const loadAttendance = (cid = '') => {
    const params = cid ? { course_id: cid } : {}
    studentAPI.getAttendance(params).then(r => { setRecords(r.data.records); setSummary(r.data.summary) })
  }

  const handleCourseChange = (cid) => { setSelectedCourse(cid); loadAttendance(cid) }

  const statusColor = { present: 'success', absent: 'error', late: 'warning' }

  return (
    <Box>
      <Typography variant="h5" fontWeight={700} mb={3}>My Attendance</Typography>

      <Grid container spacing={2} mb={3}>
        {summary.map(s => (
          <Grid item xs={12} sm={6} md={4} key={s.course_id}>
            <Card>
              <CardContent>
                <Typography variant="subtitle2" fontWeight={600} noWrap>{s.course_name}</Typography>
                <Box display="flex" justifyContent="space-between" alignItems="center" mt={1} mb={0.5}>
                  <Typography variant="body2" color="text.secondary">{s.present}/{s.total} classes</Typography>
                  <Chip label={`${s.percentage}%`} color={s.percentage >= 75 ? 'success' : s.percentage >= 60 ? 'warning' : 'error'} size="small" />
                </Box>
                <LinearProgress
                  variant="determinate"
                  value={s.percentage}
                  color={s.percentage >= 75 ? 'success' : s.percentage >= 60 ? 'warning' : 'error'}
                  sx={{ height: 6, borderRadius: 3 }}
                />
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      <FormControl fullWidth sx={{ mb: 3 }}>
        <InputLabel>Filter by Course</InputLabel>
        <Select value={selectedCourse} onChange={e => handleCourseChange(e.target.value)} label="Filter by Course">
          <MenuItem value="">All Courses</MenuItem>
          {courses.map(c => <MenuItem key={c.id} value={c.id}>{c.code} — {c.name}</MenuItem>)}
        </Select>
      </FormControl>

      <Paper>
        <Table size="small">
          <TableHead sx={{ bgcolor: '#f5f5f5' }}>
            <TableRow><TableCell>Course</TableCell><TableCell>Date</TableCell><TableCell>Status</TableCell><TableCell>Remarks</TableCell></TableRow>
          </TableHead>
          <TableBody>
            {records.map(r => (
              <TableRow key={r.id} hover>
                <TableCell>
                  <Typography variant="body2" fontWeight={500}>{r.course_name}</Typography>
                  <Typography variant="caption" color="text.secondary">{r.course_code}</Typography>
                </TableCell>
                <TableCell>{new Date(r.date).toLocaleDateString('en-GB', { weekday: 'short', day: '2-digit', month: 'short', year: 'numeric' })}</TableCell>
                <TableCell><Chip label={r.status.toUpperCase()} color={statusColor[r.status] || 'default'} size="small" /></TableCell>
                <TableCell><Typography variant="caption">{r.remarks || '-'}</Typography></TableCell>
              </TableRow>
            ))}
            {records.length === 0 && (
              <TableRow><TableCell colSpan={4} align="center"><Typography py={3} color="text.secondary">No attendance records</Typography></TableCell></TableRow>
            )}
          </TableBody>
        </Table>
      </Paper>
    </Box>
  )
}
