import React, { useEffect, useState } from 'react'
import { Box, Typography, Grid, Card, CardContent, Paper, Table, TableBody, TableCell, TableHead, TableRow, Chip, Alert } from '@mui/material'
import SchoolIcon from '@mui/icons-material/School'
import CheckBoxIcon from '@mui/icons-material/CheckBox'
import GradeIcon from '@mui/icons-material/Grade'
import SecurityIcon from '@mui/icons-material/Security'
import { studentAPI } from '../../services/api'

export default function StudentDashboard() {
  const [data, setData] = useState(null)
  const [error, setError] = useState('')

  useEffect(() => { studentAPI.dashboard().then(r => setData(r.data)).catch(() => setError('Failed to load')) }, [])

  if (error) return <Alert severity="error">{error}</Alert>
  if (!data) return null

  const { student, stats, login_history } = data

  return (
    <Box>
      <Typography variant="h5" fontWeight={700} mb={1}>Welcome, {student?.full_name}</Typography>
      <Typography variant="body2" color="text.secondary" mb={3}>
        {student?.student_id} • {student?.department_name} • Semester {student?.semester}
      </Typography>

      <Grid container spacing={2} mb={4}>
        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent>
              <Box display="flex" alignItems="center" justifyContent="space-between">
                <Box>
                  <Typography variant="body2" color="text.secondary">Enrolled Courses</Typography>
                  <Typography variant="h4" fontWeight={700} color="primary.main">{stats.total_courses}</Typography>
                </Box>
                <SchoolIcon sx={{ fontSize: 36, color: '#1565c0', opacity: 0.3 }} />
              </Box>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent>
              <Box display="flex" alignItems="center" justifyContent="space-between">
                <Box>
                  <Typography variant="body2" color="text.secondary">Attendance</Typography>
                  <Typography variant="h4" fontWeight={700} color={stats.attendance_percentage >= 75 ? 'success.main' : 'error.main'}>
                    {stats.attendance_percentage}%
                  </Typography>
                </Box>
                <CheckBoxIcon sx={{ fontSize: 36, color: '#00796b', opacity: 0.3 }} />
              </Box>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent>
              <Box display="flex" alignItems="center" justifyContent="space-between">
                <Box>
                  <Typography variant="body2" color="text.secondary">CGPA</Typography>
                  <Typography variant="h4" fontWeight={700} color="warning.main">{stats.cgpa}</Typography>
                </Box>
                <GradeIcon sx={{ fontSize: 36, color: '#e65100', opacity: 0.3 }} />
              </Box>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent>
              <Box display="flex" alignItems="center" justifyContent="space-between">
                <Box>
                  <Typography variant="body2" color="text.secondary">Notifications</Typography>
                  <Typography variant="h4" fontWeight={700} color="info.main">{stats.unread_notifications}</Typography>
                </Box>
                <SecurityIcon sx={{ fontSize: 36, color: '#0288d1', opacity: 0.3 }} />
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      <Typography variant="h6" fontWeight={600} mb={2}>Recent Login Activity</Typography>
      <Paper>
        <Table size="small">
          <TableHead sx={{ bgcolor: '#f5f5f5' }}>
            <TableRow><TableCell>Action</TableCell><TableCell>IP Address</TableCell><TableCell>Status</TableCell><TableCell>Time</TableCell></TableRow>
          </TableHead>
          <TableBody>
            {login_history.map(l => (
              <TableRow key={l.id} hover>
                <TableCell>{l.action}</TableCell>
                <TableCell><Typography variant="caption" fontFamily="monospace">{l.ip_address}</Typography></TableCell>
                <TableCell><Chip label={l.status} color="success" size="small" /></TableCell>
                <TableCell><Typography variant="caption">{new Date(l.timestamp).toLocaleString()}</Typography></TableCell>
              </TableRow>
            ))}
            {login_history.length === 0 && (
              <TableRow><TableCell colSpan={4} align="center"><Typography variant="body2" py={2} color="text.secondary">No login history</Typography></TableCell></TableRow>
            )}
          </TableBody>
        </Table>
      </Paper>
    </Box>
  )
}
