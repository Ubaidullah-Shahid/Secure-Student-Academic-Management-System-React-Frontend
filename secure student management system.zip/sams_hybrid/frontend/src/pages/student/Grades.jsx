import React, { useEffect, useState } from 'react'
import { Box, Typography, Paper, Table, TableBody, TableCell, TableHead, TableRow, Chip, Card, CardContent, Grid } from '@mui/material'
import { studentAPI } from '../../services/api'

const gradeColor = (g) => {
  if (!g) return 'default'
  if (['A+', 'A', 'A-'].includes(g)) return 'success'
  if (['B+', 'B', 'B-'].includes(g)) return 'primary'
  if (['C+', 'C', 'C-'].includes(g)) return 'warning'
  return 'error'
}

export default function StudentGrades() {
  const [grades, setGrades] = useState([])
  const [cgpa, setCgpa] = useState(0)

  useEffect(() => {
    studentAPI.getGrades().then(r => { setGrades(r.data.grades); setCgpa(r.data.cgpa) })
  }, [])

  return (
    <Box>
      <Typography variant="h5" fontWeight={700} mb={3}>My Academic Grades</Typography>

      <Grid container spacing={2} mb={3}>
        <Grid item xs={12} sm={4}>
          <Card sx={{ bgcolor: '#1565c0', color: '#fff' }}>
            <CardContent>
              <Typography variant="body2" sx={{ opacity: 0.8 }}>Cumulative GPA (CGPA)</Typography>
              <Typography variant="h3" fontWeight={700}>{cgpa.toFixed(2)}</Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={4}>
          <Card>
            <CardContent>
              <Typography variant="body2" color="text.secondary">Total Courses Graded</Typography>
              <Typography variant="h3" fontWeight={700} color="primary.main">{grades.length}</Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={4}>
          <Card>
            <CardContent>
              <Typography variant="body2" color="text.secondary">Passed Courses</Typography>
              <Typography variant="h3" fontWeight={700} color="success.main">
                {grades.filter(g => g.grade_points >= 1.0).length}
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      <Paper>
        <Table>
          <TableHead sx={{ bgcolor: '#0d1b3e' }}>
            <TableRow>
              <TableCell sx={{ color: '#fff' }}>Course</TableCell>
              <TableCell sx={{ color: '#fff' }}>Midterm</TableCell>
              <TableCell sx={{ color: '#fff' }}>Final</TableCell>
              <TableCell sx={{ color: '#fff' }}>Assignment</TableCell>
              <TableCell sx={{ color: '#fff' }}>Quiz</TableCell>
              <TableCell sx={{ color: '#fff' }}>Total</TableCell>
              <TableCell sx={{ color: '#fff' }}>Grade</TableCell>
              <TableCell sx={{ color: '#fff' }}>GPA Points</TableCell>
              <TableCell sx={{ color: '#fff' }}>Semester</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {grades.map(g => (
              <TableRow key={g.id} hover>
                <TableCell>
                  <Typography fontWeight={500}>{g.course_name}</Typography>
                  <Typography variant="caption" color="text.secondary">{g.course_code}</Typography>
                </TableCell>
                <TableCell>{g.midterm_marks}</TableCell>
                <TableCell>{g.final_marks}</TableCell>
                <TableCell>{g.assignment_marks}</TableCell>
                <TableCell>{g.quiz_marks}</TableCell>
                <TableCell><Typography fontWeight={700}>{g.total_marks}</Typography></TableCell>
                <TableCell><Chip label={g.grade_letter || 'N/A'} color={gradeColor(g.grade_letter)} /></TableCell>
                <TableCell><Typography fontWeight={600}>{g.grade_points?.toFixed(1)}</Typography></TableCell>
                <TableCell><Chip label={g.semester || '-'} size="small" variant="outlined" /></TableCell>
              </TableRow>
            ))}
            {grades.length === 0 && (
              <TableRow><TableCell colSpan={9} align="center"><Typography py={3} color="text.secondary">No grades recorded yet</Typography></TableCell></TableRow>
            )}
          </TableBody>
        </Table>
      </Paper>
    </Box>
  )
}
