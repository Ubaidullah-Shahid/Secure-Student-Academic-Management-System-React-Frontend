#!/bin/bash
# ============================================================
# SAMS Hybrid Setup Script
# Secure Academic Management System v1.1.0
# ============================================================
set -e

echo ""
echo "==========================================="
echo "  SAMS - Secure Academic Management System"
echo "  v1.1.0 Hybrid (Full Features)"
echo "==========================================="
echo ""

# Backend setup
echo "[1/4] Setting up Python virtual environment..."
cd backend
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip --quiet
pip install -r requirements.txt --quiet
echo "      Backend dependencies installed."

# Frontend setup
echo "[2/4] Installing frontend dependencies..."
cd ../frontend
npm install --silent
echo "      Frontend dependencies installed."

echo "[3/4] Initializing database with seed data..."
cd ../backend
source venv/bin/activate
python3 -c "
from app import create_app
app = create_app()
print('      Database created and admin user seeded.')
"

echo "[4/4] Setup complete!"
echo ""
echo "==========================================="
echo "  Default Login Credentials"
echo "==========================================="
echo "  Admin   → username: admin  | password: Admin@123"
echo "==========================================="
echo ""
echo "Run ./start.sh to launch SAMS"
echo ""
