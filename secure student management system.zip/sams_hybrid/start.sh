#!/bin/bash
# ============================================================
# SAMS Hybrid Start Script
# ============================================================
echo ""
echo "==========================================="
echo "  Starting SAMS v1.1.0"
echo "==========================================="

# Start backend
echo "[Backend] Starting Flask API on http://localhost:5000 ..."
cd backend
source venv/bin/activate
python3 run.py &
BACKEND_PID=$!
echo "          PID: $BACKEND_PID"

sleep 2

# Start frontend
echo "[Frontend] Starting React Dev Server on http://localhost:5173 ..."
cd ../frontend
npm run dev &
FRONTEND_PID=$!
echo "           PID: $FRONTEND_PID"

echo ""
echo "==========================================="
echo "  SAMS is running!"
echo "  Open: http://localhost:5173"
echo "==========================================="
echo ""
echo "Press Ctrl+C to stop..."

trap "kill $BACKEND_PID $FRONTEND_PID 2>/dev/null; echo 'SAMS stopped.'" EXIT
wait
